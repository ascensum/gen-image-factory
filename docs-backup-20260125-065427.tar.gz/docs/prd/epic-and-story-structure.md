# Epic and Story Structure

## Epic 1: CLI to Full Electron Application with UI and Persistence

**Epic Goal**: This epic will deliver a fully functional desktop application with a graphical user interface that encapsulates the existing CLI tool's power, adds database persistence for job history and configurations, and is packaged for easy distribution on major operating systems.

**User Stories (in implementation order):**

### Status Notes (2025-11-02)

- Story 10 (UI Visual Cleanup & Consistency): Done; unified progress behavior, counters/filters correctness, and labeling parity applied.
- Provider swap to Runware: Done; Runware is default; Midjourney‑specific UI actions removed.
- Export UX: Updated; single‑job Excel via modal (.xlsx) and bulk ZIP export via modal; `exceljs` used end‑to‑end.
- Distribution policy: Automated release pipeline triggered by Git Tags (Story 1.21); Windows uses Microsoft Store (mandatory, primary) with MSIX packages; GitHub Releases (secondary, unsigned) for advanced users; macOS/Linux use GitHub Releases with `electron-updater` for automatic updates.

1.  **Foundation: Setup Basic Electron Shell**
    - Create Electron main process
    - Setup basic window and renderer process
    - Establish project structure with `/electron` directory
    - Configure Vite for React + TypeScript development
    - Setup Tailwind CSS for styling
    - Implement basic IPC communication

2.  **Backend Integration: Implement Backend Adapter and IPC Bridge**
    - Create Backend Adapter (NFR5) for UI-backend communication
    - Implement secure IPC bridge between processes
    - Integrate existing CLI modules with minimal refactoring (CR1)
    - Setup error handling and user-friendly message translation
    - Configure TypeScript types for IPC communication

3.  **Database Foundation: Setup SQLite Database and Models**
    - Implement SQLite database setup
    - Create JobConfiguration, JobExecution, and GeneratedImage models
    - Setup database service layer
    - Implement secure credential storage with Keytar (NFR2)
    - Define TypeScript interfaces for database models

4.  **Configuration: Implement Application Settings UI - (DONE)**
    - Create settings management interface for all `.env` parameters (FR1)
    - Implement file browser for input files (FR2)
    - Add API key management with secure storage
    - Include cost labeling for API features (FR12)
    - Integrate with database for configuration persistence
    - Style UI components with Tailwind CSS



5.  **Core Controls: Implement Main Dashboard and Pipeline Controls**
    - Create main dashboard with start/stop controls (FR3)
    - Implement real-time progress indicator (FR4)
    - Add dual-mode logging (Standard/Debug) (FR4, FR10)
    - Include force stop all processes button (FR11)
    - Ensure responsive UI during backend processing (NFR1)
    - Style dashboard components with Tailwind CSS

6.  **Results: Implement 'Successful Results' View - (DONE)**
    - Create results gallery view
    - Display images with metadata and QC status (FR5)
    - Implement Excel export functionality (FR8)
    - Add image metadata display
    - Style gallery components with Tailwind CSS

7.  **Review: Implement 'Failed Images' Review Workflow**
    - Create failed images review interface
    - Display QC failure reasons (FR5)
    - Implement manual approval workflow
    - Add retry mechanisms for failed images
    - Style review components with Tailwind CSS

8.  **Persistence: Implement Job History and Advanced Features**
    - Complete job configuration saving (FR6)
    - Implement job results saving with full history (FR7)
    - Create job history view and management
    - Add data export and cleanup features
    - Style history components with Tailwind CSS

9.  **Critical Backend Fixes and Technical Debt Resolution**
    

10.  **UI Visual Cleanup & Consistency**
    - Address visual inconsistencies and responsiveness across Dashboard, Job Management, Single Job View and Settings
    - Standardize status badges and input behaviors
    - Ensure responsive headers and consistent field widths
    - Align Single Job View edit with file pickers and stats layout

11. **Provider Swap to Runware (Unified Image Inference)**
    - Replace legacy Midjourney provider with Runware as the default
    - Hide MJ‑specific UI actions; introduce Runware settings and advanced controls
    - Keep pipeline intact (download → processing → DB → QC/metadata → final move)

12. **Results Advanced Export and File Management**
    - Add ZIP export button to ImageGallery for selected images
    - Package selected images with Excel metadata into downloadable ZIP files
    - Implement backend ZIP creation service with progress tracking
    - Create logical folder structure (images/ + metadata.xlsx)
    - Add file validation and error handling for missing images
    - Style ZIP export components with Tailwind CSS

13. **Project Housekeeping: Cleanup Junk, Logs, and Emoji Policy**
    - Remove existing junk artifacts; expand `.gitignore` to prevent future junk
    - Enforce emoji policy: allowed only in `.md`; reject in code/logs/commits
    - Clean up logging output (no emojis/glyphs; standardized levels; redaction)
    - Add repo hygiene scripts (`repo:scan`, `repo:clean`) and update pre-commit hook

14. **UI Cosmetic Polish & Minor Fixes (Ongoing Small PR Lane)**
    - Incremental non-functional visual polish: spacing, alignment, typography, badges
    - Consistent hover/focus states; dark/light consistency; microcopy clarity
    - Small, low-risk PRs with brief change log entries and before/after when helpful

15. **Acceptance Fixes & Stabilization**
    - Resolve blocking and major acceptance test issues (output paths, date filters, orphaned jobs)
    - Stabilize Runware Advanced gating and LoRA support
    - Implement WebP support and remove forced PNG conversion
    - Fix Remove.bg failures and retry handling (soft/technical failure modes)
    - UI visual polish and consistency updates (Gallery, Failed Review, etc.)

16. **Security: Implement Production Security Measures**
    - Implement encrypted database fallback for API key storage
    - Add comprehensive memory protection for sensitive data
    - Create secure logging that masks API keys and sensitive information
    - Add security health checks and monitoring capabilities
    - Style security components with Tailwind CSS

17. **Testing: Implement Comprehensive Testing for Story 1.1**
    - Create unit tests for React components using React Testing Library
    - Implement integration tests for IPC communication
    - Create end-to-end tests for basic app functionality
    - Validate TypeScript type safety and configuration
    - Test cross-platform compatibility (Windows, macOS, Linux)
    - Implement security tests for IPC and app security
    - Create performance and build optimization tests

18. **Testing Stabilization & Post-1.9 Remediation: Unit & Integration (Story 1.18)**
    - Stabilize database integration tests using in-memory/isolated SQLite and migrations in setup
    - Align settings integration tests with `BackendAdapter` (replace legacy `SettingsAdapter` usage)
    - Centralize Electron and `keytar` mocks; assert IPC handlers and payloads
    - Reflect Story 1.7 clamping rules in assertions
    - Provide npm scripts for targeted subsets (DB, settings, story-1.7)
    - Remediate failing tests introduced after Story 1.9 development, excluding unit/integration/E2E already green and covered by the HySky pre-commit script

19. **Testing Coverage Elevation** (Story 1.19)
    - Implement comprehensive test coverage for critical scenarios (Settings, JobRunner, RetryExecutor)
    - Define must-not-regress scenario suite
    - Achieve ≥70% coverage targets for stable API-like modules
    - Create scenario-driven testing approach for orchestration modules

20. **Setup Quality Gates & CI** (Story 1.20) - (DONE)
    - Implement mandatory local pre-commit quality gates (ESLint, critical tests, Semgrep, Socket.dev)
    - Create comprehensive CI pipeline with build, tests, CodeQL, Semgrep, Socket.dev, npm audit
    - Configure E2E test execution workflows (nightly, version tags, manual dispatch)
    - Add scheduled CodeQL weekly security scans
    - Optimize E2E test execution strategy (chromium-only for manual/tag runs, full cross-browser for nightly)
    - Document quality gate process and test-to-scenario mapping

20.1. **Fix E2E Test Failures** (Story 1.20.1) - (DONE - Rescoped)
    - Investigate and fix all viable E2E test failures (65 active tests now pass)
    - Address timing/race condition issues using Active State Synchronization pattern
    - Improve test reliability and resilience for CI environment (sandbox args, timeouts, Electron API stubs)
    - Ensure tests work in both local and CI environments (cross-platform: macOS, Windows, Linux)
    - Properly skip tests with expected limitations (19 tests: 17 require Electron backend, 2 have flaky UI rendering)
    - Document root causes, fixes, and test coverage analysis
    - **Outcome**: All active E2E tests pass consistently; skipped tests are documented with rationale and integration test coverage references

21. **Distribution: Implement Application Packaging** (Story 1.21)
    - Configure Electron Builder for cross-platform packaging (NFR3)
    - Generate distributable installers for Windows, macOS, and Linux
    - **Automated Release Pipeline**: Triggered by Git Tags (e.g., `v*.*.*`) automatically builds artifacts and uploads to GitHub Releases
    - **Windows Distribution**: Microsoft Store (mandatory, primary) with MSIX packages; GitHub Releases (secondary, unsigned) for advanced users
    - **macOS/Linux**: GitHub Releases with `electron-updater` for automatic updates
    - **Auto-Update**: Conditional based on runtime environment (Windows Store uses OS updates; GitHub Releases uses `electron-updater`)
    - **Artifact Integrity**: SHA-256 checksums and SBOM required for every release
    - Create deployment documentation
    - Optimize Vite build for production

22. **Repository Documentation for Microsoft Store Review** (Story 1.22)
    - Create comprehensive README.md with Shiftline Tools branding
    - Create SECURITY.md with security policy and vulnerability reporting
    - Create .github/FUNDING.yml with funding/donation links
    - Ensure all documentation meets Microsoft Store review requirements

## Epic 2: Project Documentation Website

**Epic Goal**: This epic will deliver a public-facing documentation website that provides user-friendly documentation for the desktop application while maintaining a clear separation from internal project documentation (PRD, stories, architecture).

**User Stories (in implementation order):**

1. **Docs Structure Migration & Firewall** (Story 2.1)
    - Create `docs/public_docs/` directory structure for user-facing documentation
    - Migrate user-facing documentation components (dashboard usage, settings, workflows, export functionality)
    - Implement privacy firewall to exclude internal documentation (PRD, stories, architecture)
    - Verify no sensitive internal information is exposed in public docs
    - Document migration process and firewall rules

2. **Docusaurus Scaffolding & Branding** (Story 2.2)
    - Install and scaffold Docusaurus in `/website` directory
    - Configure site to consume content from `../docs/public_docs/`
    - Apply Tauri Dark Mode theme and branding to match desktop application
    - Set up basic site structure, navigation, and sidebar
    - Validate local development and build process

3. **Website Deployment** (Story 2.3)
    - Create GitHub Actions workflow for automated deployment
    - Configure custom domain and DNS settings
    - Set up automated deployment on push to `main`
    - Enable HTTPS and validate deployment process
    - Document rollback procedures

4. **Legal Pages for Microsoft Store Compliance** (Story 2.5)
    - Create Privacy Policy page (required for Microsoft Store certification)
    - Create Terms of Service page (required for Microsoft Store certification)
    - Integrate legal pages into website navigation and footer
    - Ensure content meets Microsoft Store requirements

5. **Website Hero Home Page and Resources Page** (Story 2.6)
    - Create professional hero/home page (replaces standard docs index)
    - Create resources/affiliate page for transparency about third-party services
    - Update website routing and navigation
    - Ensure professional presentation with Shiftline Tools branding

6. **Microsoft Store Identity Migration** (Story 2.7)
    - Migrate Microsoft Store identity from personal account to Shiftline Tools organization
    - Update package.json and all documentation with new identity
    - Validate build and submission process with new identity
    - Document migration process and checklist

**Testing Strategy**: Each story includes comprehensive testing tasks covering unit tests, integration tests, and end-to-end validation as appropriate for the story scope. TypeScript will provide additional type safety during development. Story 1.17 specifically addresses the testing requirements for the foundational components from Story 1.1. Story 1.18 stabilizes unit and integration tests to ensure CI reliability and alignment with current architecture. Story 1.19 elevates test coverage with must-not-regress scenarios. Story 1.20 implements quality gates and CI infrastructure with optimized E2E test execution strategy.

## Epic 3: Total Refactoring & Strangler Fig Migration

**Epic Goal**: This epic will systematically decompose all frozen monolithic files (12 files totaling ~16,000 lines) into modular, maintainable services following the Strangler Fig pattern. All extractions will use Shadow Bridge pattern with feature toggles, comprehensive testing, and safe rollout strategies to ensure zero downtime and production stability.

**Epic Context:**
- **Governance Framework:** 10 ADRs (ADR-001 through ADR-012) define the complete refactoring strategy
- **Master Frozen List:** 12 files (6 backend, 4 frontend, 1 test, 1 CSS) are **FROZEN** - no new logic may be added
- **File Size Limit:** All source files must be < 400 lines (ADR-001)
- **Strangler Fig Pattern:** Legacy code remains until new services are proven stable (ADR-006)
- **Feature Toggle Requirement:** Every extraction must use Shadow Bridge pattern with `FEATURE_MODULAR_*` toggles
- **Mandatory Testing:** ≥70% coverage for new services, 100% for bridge logic (ADR-006)

**User Stories (in implementation order):**

### Story 3.1: Backend Service Extraction
**Goal:** Extract monolithic backend services (`jobRunner.js` 3,381 lines, `backendAdapter.js` 3,407 lines) into focused, testable services following Vertical Slice Architecture (ADR-002) and Dependency Injection (ADR-003).

**Frozen Files:**
- `src/services/jobRunner.js` (3,381 lines)
- `src/adapter/backendAdapter.js` (3,407 lines)

**Extraction Strategy:**

**From jobRunner.js → Extract:**
1. **JobEngine** (< 400 lines)
   - Pure orchestration: Init → ParamGen → ImageGen → QC → Metadata
   - Returns Result Objects (no direct DB calls)
   - Feature Toggle: `FEATURE_MODULAR_JOB_ENGINE`

2. **JobService** (< 400 lines)
   - Orchestrates JobEngine + JobRepository
   - Event-based coordination
   - Feature Toggle: `FEATURE_MODULAR_JOB_SERVICE`

**From backendAdapter.js → Extract:**
1. **SecurityService** (< 400 lines)
   - API Key management, encryption/decryption, keytar interaction
   - Extract from lines ~50-150
   - Feature Toggle: `FEATURE_MODULAR_SECURITY`

2. **ExportService** (< 400 lines)
   - Excel reports and ZIP archives
   - Extract from lines ~2200-2600
   - Feature Toggle: `FEATURE_MODULAR_EXPORT`

3. **IPC Controllers** (< 400 lines each)
   - `JobController.js` - `job:*` events (< 5 lines per handler)
   - `SettingsController.js` - `settings:*` events
   - `ExportController.js` - `export:*` events
   - `SecurityController.js` - `security:*` events
   - Feature Toggle: `FEATURE_MODULAR_IPC_CONTROLLERS`

**Acceptance Criteria:**
- [ ] All extracted services < 400 lines
- [ ] Vitest unit tests with ≥70% coverage for all services
- [ ] Bridge integration tests with 100% coverage (flag enabled/disabled paths)
- [ ] Feature toggles default to `false` (legacy active)
- [ ] IPC handlers < 5 lines, delegate to services
- [ ] All dependencies injected via constructor (no global state)
- [ ] E2E tests pass with flags both enabled and disabled
- [ ] Documentation updated with service boundaries

**Definition of Done:**
- All new services deployed to `main` with feature toggles disabled
- Legacy code remains intact and functional
- Full test suite passes (unit, integration, E2E)
- Code review approved
- ADR-002 and ADR-003 compliance verified

---

### Story 3.2: Persistence Repository Layer
**Goal:** Extract business logic from database models (`JobExecution.js` 1,100 lines, `GeneratedImage.js` 1,000 lines) into Repository Layer, reducing models to < 200 lines schema-only (ADR-009).

**Frozen Files:**
- `src/database/models/JobExecution.js` (1,100 lines)
- `src/database/models/GeneratedImage.js` (1,000 lines)

**Extraction Strategy:**

**Create Repositories:**
1. **JobRepository** (< 400 lines)
   - Extract from JobExecution.js: `getJobHistory`, `getJobStatistics`, `getJobExecution`, `saveJobExecution`, `updateJobExecution`, `deleteJobExecution`, `getJobExecutions`
   - Feature Toggle: `FEATURE_MODULAR_JOB_REPOSITORY`

2. **ImageRepository** (< 400 lines)
   - Extract from GeneratedImage.js: `getImageMetadata`, `getImageStatistics`, `updateMetadataById`, `getImagesByQcStatus`, `bulkUpdateQcStatus`, `deleteImagesByExecution`
   - Feature Toggle: `FEATURE_MODULAR_IMAGE_REPOSITORY`

3. **JobConfigurationRepository** (< 400 lines)
   - Extract configuration CRUD operations
   - Feature Toggle: `FEATURE_MODULAR_CONFIG_REPOSITORY`

**Target Model State (< 200 lines each):**
- Schema definition only (CREATE TABLE)
- Basic `init()` and `close()` methods
- Database path resolution
- NO query logic, hooks, or instance methods

**Acceptance Criteria:**
- [ ] All repositories < 400 lines
- [ ] All models reduced to < 200 lines (schema only)
- [ ] Vitest unit tests with ≥70% coverage for repositories
- [ ] Bridge integration tests with 100% coverage
- [ ] Feature toggles default to `false` (legacy active)
- [ ] Dependencies injected via constructor (ADR-003)
- [ ] Services updated to use repositories (not models directly)
- [ ] E2E tests pass with flags both enabled and disabled

**Definition of Done:**
- Repositories deployed to `main` with feature toggles disabled
- Models reduced to schema-only
- Full test suite passes
- Code review approved
- ADR-009 compliance verified

---

### Story 3.3: Image Production Pipeline
**Goal:** Extract `producePictureModule.js` (799 lines) into three domain-focused services following Buffer-based pipeline architecture (ADR-008).

**Frozen File:**
- `src/producePictureModule.js` (799 lines)

**Extraction Strategy:**

1. **ImageGeneratorService** (< 400 lines)
   - Runware API integration and URL extraction
   - Extract from lines ~223-519
   - Standard Interface: `async generateImages(config, abortSignal): Promise<Array<string>>`
   - Feature Toggle: `FEATURE_MODULAR_GENERATOR`

2. **ImageRemoverService** (< 400 lines)
   - remove.bg API integration + alpha trimming
   - Extract from lines ~21-87, ~584-692
   - Standard Interface: `async removeBackground(input: Buffer, options): Promise<Buffer>`
   - Feature Toggle: `FEATURE_MODULAR_REMOVER`

3. **ImageProcessorService** (< 400 lines)
   - Sharp-based image manipulation (enhancement, conversion)
   - Extract from lines ~694-798
   - Standard Interface: `async process(input: Buffer, options): Promise<Buffer>`
   - Feature Toggle: `FEATURE_MODULAR_PROCESSOR`

**Standard Interface Contract:**
- All services accept Buffer/string and return Buffer
- Enables future Pipeline Epic with dynamic service ordering
- Testable with dummy buffers (no API keys required for ImageProcessorService)

**Acceptance Criteria:**
- [ ] All services < 400 lines
- [ ] Buffer-based interfaces (input: Buffer, output: Buffer)
- [ ] Vitest unit tests with ≥70% coverage
- [ ] ImageProcessorService testable without external dependencies
- [ ] Bridge integration tests with 100% coverage
- [ ] Feature toggles default to `false` (legacy active)
- [ ] E2E tests pass with flags both enabled and disabled
- [ ] producePictureModule.js becomes bridge router

**Definition of Done:**
- Services deployed to `main` with feature toggles disabled
- Full test suite passes
- Code review approved
- ADR-008 compliance verified
- Prepares for future Pipeline Epic

---

### Story 3.4: Atomic React Panel Decomposition
**Goal:** Decompose monolithic React panels (4 panels totaling ~5,300 lines) into Atomic Components following View/Component/Hook architecture (ADR-010) and convert CSS to Tailwind-First (ADR-007).

**Frozen Files:**
- `src/renderer/components/Dashboard/DashboardPanel.tsx` (1,600 lines)
- `src/renderer/components/Settings/SettingsPanel.tsx` (1,400 lines)
- `src/renderer/components/Dashboard/FailedImagesReviewPanel.tsx` (1,200 lines)
- `src/renderer/components/Jobs/JobManagementPanel.tsx` (1,100 lines)
- `src/renderer/components/Jobs/SingleJobView.css` (1,300 lines)

**Extraction Strategy (per Panel):**

**1. DashboardPanel.tsx (1,600 lines) →**
- **View:** `DashboardView.tsx` (< 400 lines) - Main container
- **Components:**
  - `JobControls.tsx`, `LogViewer.tsx`, `JobHistory.tsx`, `ImageGallery.tsx`, `HeaderMenu.tsx`, `StatisticsCard.tsx`
  - All < 400 lines each
- **Hooks:**
  - `useJobHistory.ts`, `useJobStatus.ts`, `useImageGallery.ts`, `useExportOperations.ts`
  - All < 400 lines each

**2. SettingsPanel.tsx (1,400 lines) →**
- **View:** `SettingsView.tsx` (< 400 lines) - Tab navigation container
- **Components:**
  - `ApiKeysSection.tsx`, `FilePathsSection.tsx`, `ParametersSection.tsx`, `ProcessingSection.tsx`, `AISection.tsx`, `AdvancedSection.tsx`
  - Already exist, verify < 400 lines
- **Hooks:**
  - `useSettings.ts`, `useApiKeys.ts`, `useFilePaths.ts`

**3. FailedImagesReviewPanel.tsx (1,200 lines) →**
- **View:** `FailedImagesReviewView.tsx` (< 400 lines)
- **Components:**
  - `FailedImageList.tsx`, `FailedImageCard.tsx`, `ReviewActions.tsx`, `BulkActions.tsx`
- **Hooks:**
  - `useFailedImages.ts`, `useImageReview.ts`

**4. JobManagementPanel.tsx (1,100 lines) →**
- **View:** `JobManagementView.tsx` (< 400 lines)
- **Components:**
  - `JobList.tsx`, `JobCard.tsx`, `JobFilters.tsx`, `JobActions.tsx`
- **Hooks:**
  - `useJobList.ts`, `useJobOperations.ts`

**5. SingleJobView.css (1,300 lines) → Tailwind-First (ADR-007)**
- Convert 90% of styles to inline Tailwind classes in `.tsx` files
- Extract complex animations to CSS Module (< 100 lines)
- Delete original CSS file once migration complete

**Acceptance Criteria:**
- [ ] All view containers < 400 lines
- [ ] All atomic components < 400 lines
- [ ] All custom hooks < 400 lines
- [ ] 90% of styles converted to Tailwind utilities
- [ ] CSS Modules (if needed) < 100 lines
- [ ] React Testing Library tests with ≥70% coverage
- [ ] Vitest hook tests with mocked dependencies
- [ ] E2E tests pass for all refactored panels
- [ ] No functional regressions

**Definition of Done:**
- All panels decomposed and deployed to `main`
- CSS migration complete
- Full test suite passes
- Code review approved
- ADR-010 and ADR-007 compliance verified

---

### Story 3.5: Retry Engine & Test Modularization
**Goal:** Decompose `retryExecutor.js` (1,160 lines) into focused services (ADR-012) and modularize integration tests (ADR-011).

**Frozen Files:**
- `src/services/retryExecutor.js` (1,160 lines)
- `tests/integration/backend/BackendAdapter.integration.test.ts` (1,000 lines)

**Extraction Strategy:**

**Retry Engine Decomposition:**
1. **RetryQueueService** (< 400 lines)
   - Queue management, job orchestration, status tracking
   - Extract from lines ~19-340
   - Feature Toggle: `FEATURE_MODULAR_RETRY_QUEUE`

2. **RetryProcessorService** (< 400 lines)
   - Individual image retry processing
   - Extract from lines ~350-1150
   - Dependencies: ImageProcessorService, ImageRepository, MetadataService
   - Feature Toggle: `FEATURE_MODULAR_RETRY_PROCESSOR`

3. **RetryExecutor** (< 200 lines)
   - Thin orchestrator wiring services together
   - Maintains EventEmitter interface for backward compatibility

**Test Suite Decomposition:**
- **From:** `BackendAdapter.integration.test.ts` (1,000 lines)
- **To:** Feature-based test suites (< 400 lines each)
  - `tests/integration/settings/SettingsAdapter.integration.test.ts`
  - `tests/integration/settings/ApiKeys.integration.test.ts`
  - `tests/integration/jobs/JobExecution.integration.test.ts`
  - `tests/integration/jobs/JobRunner.integration.test.ts`
  - `tests/integration/jobs/JobRepository.integration.test.ts`
  - `tests/integration/images/ImageRepository.integration.test.ts`
  - `tests/integration/images/ImageProcessing.integration.test.ts`
  - `tests/integration/exports/ExcelExport.integration.test.ts`
  - `tests/integration/exports/ZipExport.integration.test.ts`
  - `tests/integration/adapter/BackendAdapter.bridge.integration.test.ts`

**Shared Test Utilities:**
- Extract to `tests/integration/shared/`
- Files: `test-setup.ts`, `test-helpers.ts`, `test-fixtures.ts`
- All < 400 lines each

**Acceptance Criteria:**
- [ ] RetryQueueService < 400 lines
- [ ] RetryProcessorService < 400 lines
- [ ] RetryExecutor < 200 lines
- [ ] All integration test files < 400 lines
- [ ] Vitest unit tests with ≥70% coverage for services
- [ ] Bridge integration tests with 100% coverage
- [ ] Feature toggles default to `false` (legacy active)
- [ ] Test coverage maintained (≥70%)
- [ ] Tests can run in parallel (isolated databases)

**Definition of Done:**
- Services deployed to `main` with feature toggles disabled
- Test suite modularized
- Full test suite passes
- Code review approved
- ADR-011 and ADR-012 compliance verified

---

### Story 3.6: Agentic Context Retention Infrastructure (ADR-013)
**Goal:** Implement Local Obsidian & Qdrant Bridge to provide AI agents with <200ms semantic search across ADRs, PRDs, stories, and standards with persistent memory across chat sessions.

**High-Level Requirements:**
- Set up local Obsidian vault as documentation source of truth (outside repository)
- Create symlink from `./docs` to Obsidian vault for IDE visibility and version control
- Configure Qdrant vector database with 4 collections (architecture, requirements, stories, standards)
- Implement Model Context Protocol (MCP) integration in Cursor IDE
- Build ingestion pipeline in separate `bmad-qdrant-knowledge-management` repository
- Integrate agent governance rules (query before refactoring, index story artifacts)
- Update story execution templates with memory query workflows
- Document developer onboarding and Obsidian setup process

**Performance Targets:**
- Semantic query latency <200ms (P95)
- 70-80% token reduction for agent context loading
- Developer setup time <30 minutes
- Full documentation ingestion <10 minutes

**References:**
- [ADR-013: Local Obsidian & Remote Qdrant Bridge](../architecture/adr/ADR-013-Obsidian-Qdrant-MCP-Bridge.md)
- [BMAD Qdrant Integration Repository](https://github.com/Hidden-History/bmad-qdrant-knowledge-management)

---

## Epic 3 Success Criteria

### **Quantitative Metrics:**
- [ ] All 12 frozen files decomposed
- [ ] All new files < 400 lines (100% compliance)
- [ ] ≥70% test coverage for all new services
- [ ] 100% test coverage for bridge logic
- [ ] Zero production regressions during migration
- [ ] All feature toggles successfully enabled in production

### **Qualitative Metrics:**
- [ ] Codebase maintainability significantly improved
- [ ] Service boundaries clear and well-documented
- [ ] Developer velocity increased (smaller files, easier navigation)
- [ ] Technical debt reduced from ~16,000 lines of monoliths to modular services
- [ ] Architecture compliant with all 10 ADRs

### **Rollout Safety:**
- [ ] All extractions use Shadow Bridge pattern (ADR-006)
- [ ] Feature toggles tested thoroughly (enabled/disabled paths)
- [ ] Immutable safety net (legacy tests) remains intact
- [ ] Rollback strategy documented and tested
- [ ] Production stability maintained throughout migration

### **Documentation Requirements:**
- [ ] All ADRs updated with implementation status
- [ ] Service boundaries documented
- [ ] Feature toggle management guide created
- [ ] Migration retrospective documented
- [ ] Architecture diagrams updated

---

## Epic 3 Risk Mitigation

### **Technical Risks:**
- **Risk:** Bridge complexity adds technical debt
  - **Mitigation:** Time-bounded feature toggles (2-3 releases max), mandatory Phase 5 cleanup
- **Risk:** Circular dependencies during extraction
  - **Mitigation:** Strict dependency injection (ADR-003), interface segregation
- **Risk:** Test coverage regression
  - **Mitigation:** Mandatory coverage gates (≥70% services, 100% bridge)

### **Process Risks:**
- **Risk:** Feature toggles forgotten, technical debt accumulates
  - **Mitigation:** Tracked in Epic 3 backlog, code review checklist includes Phase 5 cleanup
- **Risk:** Legacy code breaks during extraction
  - **Mitigation:** Immutable safety net (legacy tests must pass), feature toggles default to `false`

### **Delivery Risks:**
- **Risk:** Epic scope too large, delivery delayed
  - **Mitigation:** Incremental story delivery, each story independently deployable
- **Risk:** Production incidents during rollout
  - **Mitigation:** Phased rollout (local → staging → production), easy rollback via feature toggles

---

**Testing Strategy**: Epic 3 implements the most comprehensive testing strategy in the project. Every story mandates Shadow Bridge testing (ADR-006) with three-tier coverage: Tier 1 (unit/integration with ≥70%), Tier 2 (bridge logic with 100%), Tier 3 (E2E with flags enabled/disabled). The Modular Testing Standard (ADR-011) ensures all test files remain < 400 lines. All extractions must pass the immutable safety net (legacy integration tests) before deployment.