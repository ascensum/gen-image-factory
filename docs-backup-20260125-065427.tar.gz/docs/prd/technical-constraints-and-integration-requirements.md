# Technical Constraints and Integration Requirements

## Existing Technology Stack

The enhancement will be built upon the existing technology stack. New components must be compatible with these core technologies:

| Category | Technology |
| :--- | :--- |
| **Runtime** | Node.js (v16+) |
| **AI Integration**| Runware (primary), OpenAI for QC/metadata, Remove.bg for background removal |
| **Image Processing**| `sharp` (^0.32.0) |
| **Data Handling**| `exceljs` (^4.x), `csv-parser` (^3.2.0) |
| **HTTP Client** | `axios` (^1.3.1) |

## Integration Approach

* **Process Model**: The application will use Electron's Main Process for the Node.js backend logic and the Renderer Process for the UI.
* **Communication Bridge**: All communication will go through the **Backend Adapter** (NFR5), which will manage asynchronous communication between the two processes.
* **Error Handling**: The Backend Adapter will catch technical errors and translate them into user-friendly messages.

## Code Organization and Standards

A new `/electron` directory will be created to house all UI and Electron-specific code, keeping it separate from the existing `/src` backend logic.

### File Size Governance (ADR-001)

**CRITICAL:** All source files must be **< 400 lines**. Files exceeding this limit are **FROZEN** and subject to the Strangler Fig pattern (no new logic may be added).

**Master Frozen List (12 Files):**

The following files are **FROZEN** and must be decomposed following their respective ADR extraction strategies. These files represent the core of Epic 3 - Total Refactoring & Strangler Fig Migration.

#### Backend/Services (6 Files)
1. **`src/services/jobRunner.js`** (3,381 lines)
   - **Mitigation ADRs:** ADR-002 (Vertical Slice IPC), ADR-003 (Dependency Injection)
   - **Extraction Strategy:** Extract to JobEngine (core orchestration), JobService (persistence coordination), and feature-specific controllers
   - **Epic 3 Story:** Story 3.1 - Backend Service Extraction

2. **`src/adapter/backendAdapter.js`** (3,407 lines)
   - **Mitigation ADRs:** ADR-002 (Vertical Slice IPC), ADR-003 (Dependency Injection)
   - **Extraction Strategy:** Extract to SecurityService, JobRepository, ExportService, and IPC Controllers per feature domain
   - **Epic 3 Story:** Story 3.1 - Backend Service Extraction

3. **`src/producePictureModule.js`** (799 lines)
   - **Mitigation ADR:** ADR-008 (Image Production Layer Extraction)
   - **Extraction Strategy:** Extract to ImageGeneratorService (Runware API), ImageRemoverService (remove.bg + alpha trim), ImageProcessorService (Sharp manipulation)
   - **Epic 3 Story:** Story 3.3 - Image Production Pipeline

4. **`src/services/retryExecutor.js`** (1,160 lines)
   - **Mitigation ADR:** ADR-012 (Retry Executor Decomposition)
   - **Extraction Strategy:** Extract to RetryQueueService (queue management) and RetryProcessorService (image processing orchestration)
   - **Epic 3 Story:** Story 3.5 - Retry Engine & Test Modularization

5. **`src/database/models/JobExecution.js`** (1,100 lines)
   - **Mitigation ADR:** ADR-009 (Persistence Repository Layer)
   - **Extraction Strategy:** Reduce to < 200 lines schema-only; extract all query logic to JobRepository
   - **Epic 3 Story:** Story 3.2 - Persistence Repository Layer

6. **`src/database/models/GeneratedImage.js`** (1,000 lines)
   - **Mitigation ADR:** ADR-009 (Persistence Repository Layer)
   - **Extraction Strategy:** Reduce to < 200 lines schema-only; extract all query logic to ImageRepository
   - **Epic 3 Story:** Story 3.2 - Persistence Repository Layer

#### Frontend Components (4 Files)
7. **`src/renderer/components/Dashboard/DashboardPanel.tsx`** (1,600 lines)
   - **Mitigation ADR:** ADR-010 (Frontend Decomposition Standard)
   - **Extraction Strategy:** Extract to DashboardView + atomic components (JobControls, LogViewer, JobHistory, ImageGallery) + hooks (useJobHistory, useJobStatus, useImageGallery)
   - **Epic 3 Story:** Story 3.4 - Atomic React Panel Decomposition

8. **`src/renderer/components/Settings/SettingsPanel.tsx`** (1,400 lines)
   - **Mitigation ADR:** ADR-010 (Frontend Decomposition Standard)
   - **Extraction Strategy:** Extract to SettingsView + section components (ApiKeysSection, FilePathsSection, ParametersSection, etc.) + hooks (useSettings, useApiKeys, useFilePaths)
   - **Epic 3 Story:** Story 3.4 - Atomic React Panel Decomposition

9. **`src/renderer/components/Dashboard/FailedImagesReviewPanel.tsx`** (1,200 lines)
   - **Mitigation ADR:** ADR-010 (Frontend Decomposition Standard)
   - **Extraction Strategy:** Extract to FailedImagesReviewView + components (FailedImageList, FailedImageCard, ReviewActions, BulkActions) + hooks (useFailedImages, useImageReview)
   - **Epic 3 Story:** Story 3.4 - Atomic React Panel Decomposition

10. **`src/renderer/components/Jobs/JobManagementPanel.tsx`** (1,100 lines)
    - **Mitigation ADR:** ADR-010 (Frontend Decomposition Standard)
    - **Extraction Strategy:** Extract to JobManagementView + components (JobList, JobCard, JobFilters, JobActions) + hooks (useJobList, useJobOperations)
    - **Epic 3 Story:** Story 3.4 - Atomic React Panel Decomposition

#### Infrastructure/Tests (1 File)
11. **`tests/integration/backend/BackendAdapter.integration.test.ts`** (1,000 lines)
    - **Mitigation ADR:** ADR-011 (Modular Testing Standard)
    - **Extraction Strategy:** Decompose into feature-based test suites (settings/, jobs/, images/, exports/) with < 400 lines each
    - **Epic 3 Story:** Story 3.5 - Retry Engine & Test Modularization

#### Component Styling (1 File)
12. **`src/renderer/components/Jobs/SingleJobView.css`** (1,300 lines)
    - **Mitigation ADR:** ADR-007 (CSS Standards - Tailwind-First Development)
    - **Extraction Strategy:** Convert 90% to inline Tailwind classes; extract complex animations to CSS Modules (< 100 lines)
    - **Epic 3 Story:** Story 3.4 - Atomic React Panel Decomposition

**Governance Rules:**
- **Freeze Policy:** No new logic may be added to any file on the Master Frozen List
- **Extraction Requirement:** All changes must extract logic to new services/repositories/components following their respective ADR mitigation strategy
- **Size Limit Enforcement:** All new files must be < 400 lines (CI/Linting warns on violations)
- **Strangler Fig Pattern:** Legacy code remains until new services are proven stable (ADR-006 rollout strategy)
- **Feature Toggle Requirement:** Every extraction must use Shadow Bridge pattern with feature toggles (ADR-006)

**Definition of Done:**
- All new files must be **< 400 lines** (primary DoD criterion)
- All frozen files must have corresponding ADR-based extraction strategy
- No new logic may be added to frozen files
- Extraction must follow Strangler Fig pattern with Shadow Bridge (ADR-006)
- Every extraction must have feature toggle (format: `FEATURE_MODULAR_[SERVICE_NAME]`)
- Mandatory testing: ≥70% coverage for new services, 100% for bridge logic

**References:**
- [ADR-001: File Size Guardrail](../architecture/adr/ADR-001-File-Size-Guardrail.md)
- [ADR-006: Solo-Developer Testing & Rollout Strategy](../architecture/adr/ADR-006-Solo-Developer-Testing-Rollout.md)
- [Code Standards](../standards/CODE_STANDARDS.md)

## Development Environment & Agentic Context Retention (ADR-013)

### Requirements

**Agentic Recall:**
- The development environment must allow AI agents to semantically search ADRs, PRDs, stories, and coding standards with **<200ms latency**
- Agents must query memory before proposing architectural changes to validate against frozen file rules (ADR-001), DI patterns (ADR-003), and IPC constraints (ADR-002)
- Semantic search must return context-aware results (e.g., "What constraints apply to IPC handlers?" → ADR-002 with relevant excerpts)

**Context Persistence:**
- Refactoring decisions made during Epic 3 must be stored in persistent memory that outlives individual chat sessions
- All story execution logs must be indexed to memory on completion (governance requirement)
- Memory must support cross-project knowledge reuse for common architectural patterns (DI, Repository, Strangler Fig)

**Privacy & Locality:**
- All semantic search and document storage must happen locally to protect project IP
- Documentation source of truth remains local (Obsidian vault outside repository)
- No project-specific knowledge transmitted to cloud services without explicit developer control

### Implementation Architecture

**Component 1: Obsidian Vault (Source of Truth)**
- Location: Local file system outside repository (e.g., `~/Documents/Obsidian/BMad-Projects/gen-image-factory/`)
- Purpose: Primary editing environment with knowledge graph, backlinks, and rich markdown features
- Developer workflow: All documentation edits happen in Obsidian (not directly in `./docs`)

**Component 2: Repository Symlink (`./docs`)**
- Implementation: `ln -s ~/Documents/Obsidian/BMad-Projects/gen-image-factory ./docs`
- Purpose: IDE visibility (Cursor can read/edit), version control (Git tracks changes), agent access
- Governance: Developers must edit in Obsidian only; symlink provides read access to IDE and agents

**Component 3: Qdrant Instance (Separate Repository)**
- Repository: `https://github.com/Hidden-History/bmad-qdrant-knowledge-management`
- Deployment: Qdrant Cloud (persistent memory) or self-hosted Docker (privacy-sensitive projects)
- Collections:
  - `gen-image-factory-architecture` - ADRs, tech stack, source tree
  - `gen-image-factory-requirements` - PRD shards, epic documents
  - `gen-image-factory-stories` - Execution logs, migration notes
  - `gen-image-factory-standards` - Code standards, testing guidelines
- Ingestion: Manual trigger (`npm run ingest:gen-image-factory`) or webhook

**Component 4: MCP Integration (Model Context Protocol)**
- Protocol: stdio transport mode
- Configuration: `.cursor/mcp_config.json` (Cursor IDE)
- Tools Provided:
  - `query_memory(query, collection, limit)` - Semantic search across knowledge base
  - `ingest_document(file_path, metadata)` - Index new documents
  - `list_collections()` - Show available knowledge collections

### Governance Rules (BMAD_INTEGRATION_RULES)

**Rule 1: Query Before Refactoring**
- Requirement: All agents MUST query memory before proposing architectural changes
- Rationale: Prevents violating frozen file rules (ADR-001) or DI patterns (ADR-003)
- Enforcement: Story execution templates include memory query steps

**Rule 2: Index Story Artifacts**
- Requirement: All story completions MUST index execution logs to memory
- Rationale: Future agents learn from past refactoring decisions
- Enforcement: Story completion templates include `ingest_document()` call

**Rule 3: Semantic Query Over File Search**
- Requirement: Agents use semantic queries first, file search second
- Rationale: Memory provides context-aware results
- Enforcement: Agent prompts prioritize `query_memory()` over `grep` for documentation

**Rule 4: Local Obsidian Edits Only**
- Requirement: Developers edit documentation in Obsidian, not directly in `./docs`
- Rationale: Preserves Obsidian features (backlinks, graph) and prevents symlink corruption
- Enforcement: Documentation guidelines + CI warning if `./docs` is a regular directory

**Rule 5: Cross-Project Memory Reuse**
- Requirement: Qdrant collections may be shared across related projects
- Rationale: Common architectural patterns (DI, Repository, Strangler Fig) apply portfolio-wide
- Enforcement: Collection naming: `{project}-{category}` (e.g., `gen-image-factory-architecture`)

### Migration Strategy (Epic 3 Integration)

**Phase 1: Foundation (Week 1)**
1. Create Obsidian vault structure
2. Move `./docs` to Obsidian, create symlink
3. Set up Qdrant instance (Cloud or self-hosted)
4. Configure MCP in Cursor (`.cursor/mcp_config.json`)

**Phase 2: Ingestion (Week 1)**
1. Ingest existing ADRs (12+ documents)
2. Ingest coding standards and tech stack docs
3. Ingest PRD shards
4. Test semantic queries: "Which files are frozen?" → ADR-001

**Phase 3: Agent Integration (Week 2)**
1. Update story execution templates to include memory queries
2. Add memory query examples to agent prompts
3. Test agent memory retrieval in dry-run story

**Phase 4: Workflow Adoption (Week 2)**
1. Document Obsidian setup in `README.md`
2. Add story artifact indexing workflow
3. Train agents to index completion logs

### Performance & Quality Requirements

- **Query Latency:** <200ms for semantic search queries (P95)
- **Memory Persistence:** Story artifacts must persist across machines and chat sessions
- **Context Efficiency:** 70-80% token reduction (agents load 3-5 ADRs instead of 40+ docs)
- **Setup Time:** <30 minutes for initial developer setup (Obsidian + symlink + MCP)
- **Ingestion Time:** <10 minutes for full documentation re-ingestion

### References

- [ADR-013: Local Obsidian & Remote Qdrant Bridge](../architecture/adr/ADR-013-Obsidian-Qdrant-MCP-Bridge.md)
- [BMAD Qdrant Integration](https://github.com/Hidden-History/bmad-qdrant-knowledge-management)
- [Model Context Protocol (MCP)](https://modelcontextprotocol.info/)

## Deployment and Operations

The final application will be packaged using `electron-builder` to generate distributable installers for Windows, macOS, and Linux.

*   **Automated Cloud Builds:** Releases are built automatically by GitHub Actions when a tag is pushed.
*   **Source of Truth:** The GitHub Releases page is the official source for all distribution artifacts. Local builds are for development and debugging only.

### Release and CI Policy (2025-11-02)

- **Automated Release Pipeline**: Triggered by Git Tags (e.g., `v*.*.*`) automatically builds `electron-builder` artifacts and uploads to GitHub Releases (Story 1.21)
- **Artifact Integrity**: SHA-256 checksums and SBOM (Software Bill of Materials) required for every release
- **Release Notes Automation**: GitHub native release notes generation configured via `.github/release.yml` for automatic categorization of changes. Release workflow uses `generate_release_notes: true` to auto-generate categorized release notes from commit messages following Conventional Commits format. Helper script `scripts/extract-release-notes.js` available for Microsoft Store submission. npm scripts `release-notes` and `release-notes:latest` provide easy access to release notes (Story 1.21)
- **Auto-Update**: Conditional based on runtime environment (Windows Store uses OS updates; GitHub Releases uses `electron-updater`)
- Historical releases kept for rollback capability
- CI quality gates: run unit/integration/E2E tests, CodeQL (JavaScript/TypeScript with security-extended queries), Semgrep (OWASP Top 10 + JavaScript - see NFR7), Socket.dev (supply-chain scanning), `npm audit` (high severity only, mandatory in CI), and Dependabot (automated dependency updates via `.github/dependabot.yml` with weekly updates, grouped PRs, optional auto-merge). CodeQL must run on every push AND as a weekly scheduled job to catch security drift. E2E tests run periodically (nightly scheduled, on version tags, or manual via workflow_dispatch), not on every push. All active E2E tests must pass (tests requiring Electron backend are properly skipped; backend functionality is covered by integration tests). High‑risk findings fail CI; network retry logic ensures reliability.

### Dual-Channel Distribution Policy

- **Windows Distribution**:
  - **Primary Channel**: Microsoft Store ($0 cost signed MSIX packages) - mandatory distribution channel
  - **Secondary Channel**: GitHub Releases (unsigned NSIS installer) - for advanced users requiring offline installation or bypassing Store restrictions
- **macOS/Linux Distribution**:
  - **Primary Channel**: GitHub Releases with `electron-updater` support for automatic updates

### Microsoft Store Identity Profile

The Microsoft Store Identity Profile is immutable and defines the internal vs. public brand separation:

- **Identity Name**: Stored in GitHub secret `MS_STORE_IDENTITY_NAME` (Internal only - not user-visible)
- **Publisher**: Stored in GitHub secret `MS_STORE_PUBLISHER_ID`
- **Publisher Display Name**: Stored in GitHub secret `MS_STORE_PUBLISHER_DISPLAY_NAME` (User-visible brand)
- **Store ID**: Stored in GitHub secret `MS_STORE_STORE_ID`
- **Package Family Name (PFN)**: Stored in GitHub secret `MS_STORE_PACKAGE_FAMILY_NAME`
- **Package SID**: Stored in GitHub secret `MS_STORE_PACKAGE_SID`

**Configuration**: Values are stored in GitHub secrets for security and CI/CD automation. See `docs/microsoft-store-secrets-setup.md` for setup instructions.

### Deployment Assets

- **System-Level Icons**: Production installers must use the textless version of the circular Factory Logo for all system-level icons (.ico, .icns, .png).