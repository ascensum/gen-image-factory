# Next Steps

## Epic 3: Total Refactoring & Strangler Fig Migration (CRITICAL PREREQUISITE)

**Status:** Ready for implementation
**Priority:** HIGHEST - Epic 3 is now the mandatory prerequisite foundation before any new feature development.

### Why Epic 3 Takes Priority

**Current State - Technical Debt Crisis:**
- 12 files totaling ~16,000 lines violate the 400-line limit (ADR-001)
- Monolithic files block maintainability, testability, and future feature development
- "God Classes" combine multiple responsibilities (database, IPC, business logic, file I/O)
- Circular dependencies via global state (`global.backendAdapter`)
- New feature development requires modifying frozen monoliths (governance violation)

**Target State - Modular Foundation:**
- All files < 400 lines (100% compliance)
- Clear service boundaries with single responsibilities
- Dependency injection (no global state)
- Buffer-based pipeline architecture (future-ready)
- Comprehensive test coverage (≥70% services, 100% bridge logic)

**Governance Framework (10 ADRs):**
- ADR-001: File Size Guardrail (400-line limit)
- ADR-002: Vertical Slice Architecture for IPC
- ADR-003: Dependency Injection over Global State
- ADR-006: Solo-Developer Testing & Rollout Strategy (Shadow Bridge pattern)
- ADR-007: CSS Standards - Tailwind-First Development
- ADR-008: Image Production Layer Extraction
- ADR-009: Persistence Repository Layer
- ADR-010: Frontend Decomposition Standard
- ADR-011: Modular Testing Standard
- ADR-012: Retry Executor Decomposition

### Implementation Sequence

**Story 3.1: Backend Service Extraction (First Priority)**
- Target: `jobRunner.js` (3,381 lines) → JobEngine + JobService
- Target: `backendAdapter.js` (3,407 lines) → SecurityService, ExportService, IPC Controllers
- Benefit: Unblocks all backend feature development
- Duration: 3-4 weeks

**Story 3.2: Persistence Repository Layer (Second Priority)**
- Target: `JobExecution.js` (1,100 lines) → JobRepository
- Target: `GeneratedImage.js` (1,000 lines) → ImageRepository
- Benefit: Clean data access layer, enables database migrations
- Duration: 2-3 weeks

**Story 3.3: Image Production Pipeline (Third Priority)**
- Target: `producePictureModule.js` (799 lines) → ImageGeneratorService, ImageRemoverService, ImageProcessorService
- Benefit: Prepares for future dynamic pipeline architecture
- Duration: 2 weeks

**Story 3.4: Atomic React Panel Decomposition (Fourth Priority)**
- Target: 4 React panels (5,300 lines total) → View/Component/Hook architecture
- Target: `SingleJobView.css` (1,300 lines) → Tailwind-First
- Benefit: Maintainable frontend, enables UI feature development
- Duration: 3-4 weeks

**Story 3.5: Retry Engine & Test Modularization (Fifth Priority)**
- Target: `retryExecutor.js` (1,160 lines) → RetryQueueService + RetryProcessorService
- Target: `BackendAdapter.integration.test.ts` (1,000 lines) → Feature-based test suites
- Benefit: Clean retry mechanism, modular test suite
- Duration: 2 weeks

**Total Estimated Duration:** 12-15 weeks (3-4 months)

### Rollout Strategy (ADR-006 Shadow Bridge Pattern)

**Every extraction follows 5-phase rollout:**
1. **Phase 1 - Develop:** Create service + comprehensive tests (≥70% coverage)
2. **Phase 2 - Bridge:** Wire into monolith behind feature toggle (`FEATURE_MODULAR_*`)
3. **Phase 3 - Ship:** Deploy to `main` (legacy active, flag defaults to `false`)
4. **Phase 4 - Verify:** Enable flag locally/staging, run E2E tests
5. **Phase 5 - Finalize:** Remove bridge and legacy code after 2-3 stable releases

**Safety Mechanisms:**
- Feature toggles default to `false` (legacy code active)
- Bridge logic has 100% test coverage (both code paths)
- Immutable safety net (legacy tests must pass)
- Easy rollback (disable feature toggle without code changes)

### Success Criteria

**Before Epic 3 can be considered complete:**
- [ ] All 12 frozen files decomposed
- [ ] All new files < 400 lines (100% compliance)
- [ ] ≥70% test coverage for all new services
- [ ] 100% test coverage for bridge logic
- [ ] All feature toggles successfully enabled in production
- [ ] All Phase 5 cleanups complete (bridges and legacy code removed)
- [ ] Zero production regressions during migration
- [ ] Architecture compliant with all 10 ADRs

### Blocking Impact on Other Work

**Epic 2 Stories (Documentation Website):**
- **Can proceed in parallel:** Stories 2.1-2.7 are independent of Epic 3
- **No blockers:** Documentation work does not require modifying frozen files

**Epic 1 Stories (New Features):**
- **BLOCKED:** Any story requiring changes to frozen files (jobRunner, backendAdapter, etc.)
- **Examples:**
  - Story 1.7: Failed Images Review - requires modifying frozen panels
  - Story 1.8: Job History - requires modifying backendAdapter
  - Story 1.12: Advanced Export - requires modifying backendAdapter
- **Recommendation:** Pause Epic 1 feature development until Epic 3 Stories 3.1 and 3.2 are complete

**Bug Fixes and Hotfixes:**
- **Critical Production Bugs:** Allowed to modify frozen files with explicit ADR exception and immediate extraction plan
- **Non-Critical Bugs:** Wait for Epic 3 completion

### Resource Allocation

**Solo Developer Workflow:**
- **Primary Focus:** Epic 3 (80% time allocation)
- **Secondary:** Critical bug fixes and Epic 2 documentation (20% time allocation)
- **Recommendation:** Communicate to stakeholders that new feature development is paused for refactoring foundation

### Communication Plan

**Stakeholder Messaging:**
> "We are investing 3-4 months in Epic 3 to establish a solid architectural foundation. This refactoring will eliminate 16,000 lines of technical debt, enable faster feature development, and reduce bug risk. All work follows the Strangler Fig pattern to ensure zero production downtime."

**Progress Tracking:**
- Weekly updates on story completion
- Bi-weekly demos of extracted services (with feature toggle comparisons)
- Monthly architecture review presentations

---

## Architect Handoff (Legacy - Pre-Epic 3)

This Product Requirements Document is now finalized and ready for the architectural design phase. **However, Epic 3 (Total Refactoring & Strangler Fig Migration) must be completed before any new feature development proceeds.** 

## Release and CI (2025-11-02)

- CI quality gates:
  - Run unit/integration/E2E tests on push to `main`.
  - Run CodeQL (JavaScript) and Semgrep (OWASP Top 10 + JavaScript packs); CI fails on **any Semgrep error** (not just high-risk findings) to prevent silent failures. **Note**: `p/owasp-electron` does not exist; using `p/owasp-top-ten` + `p/javascript` instead.
  - **npm audit** (high severity only) **must** run in CI and fail workflow on high-severity vulnerabilities (NFR7).
- Automated release pipeline (Story 1.21):
  - **Triggered by Git Tags** (e.g., `v*.*.*`) automatically builds `electron-builder` artifacts and uploads to GitHub Releases
  - **Windows Distribution**: Microsoft Store (mandatory, primary) with MSIX packages; GitHub Releases (secondary, unsigned) for advanced users
  - **macOS/Linux**: GitHub Releases with `electron-updater` for automatic updates
  - **Artifact Integrity**: SHA-256 checksums and SBOM (Software Bill of Materials) required for every release
  - **Auto-Update**: Conditional based on runtime environment (Windows Store uses OS updates; GitHub Releases uses `electron-updater`)
  - Historical releases kept for rollback capability