# App Structure (Electron backend + frontend)

## Electron Backend (electron/)
├── main.js
├── preload.js
└── renderer
    ├── assets
    │   ├── 128x128-CPHoe14t.png
    │   ├── 16x16-pjf8Dx8V.png
    │   ├── 256x256-CIhSqHvO.png
    │   ├── 32x32-CkqVAdMj.png
    │   ├── 48x48-kqsO-qSn.png
    │   ├── 512x512-DCTp6Wkt.png
    │   ├── 64x64-BXQayFSL.png
    │   ├── favicon-Bba99szA.svg
    │   ├── icon-C8bAesRQ.ico
    │   ├── logo-banner-DUIGF7ij.svg
    │   ├── logo-square-W1aN-qwA.svg
    │   ├── main-BWjRAo6F.css
    │   └── main-CcvD6gCr.js
    └── index.html

## Electron Renderer (electron/renderer/)
├── assets
│   ├── 128x128-CPHoe14t.png
│   ├── 16x16-pjf8Dx8V.png
│   ├── 256x256-CIhSqHvO.png
│   ├── 32x32-CkqVAdMj.png
│   ├── 48x48-kqsO-qSn.png
│   ├── 512x512-DCTp6Wkt.png
│   ├── 64x64-BXQayFSL.png
│   ├── favicon-Bba99szA.svg
│   ├── icon-C8bAesRQ.ico
│   ├── logo-banner-DUIGF7ij.svg
│   ├── logo-square-W1aN-qwA.svg
│   ├── main-BWjRAo6F.css
│   └── main-CcvD6gCr.js
└── index.html

## Frontend (src/)
├── adapter
│   └── backendAdapter.js
├── aiVision.js
├── constant
│   ├── defaultMetadataPrompt.js
│   ├── defaultQualityCheckPrompt.js
│   └── keywords_food.js
├── database
│   ├── backupManager.js
│   ├── database.sqlite
│   ├── gen-image-factory.db
│   ├── migrations
│   │   ├── 001_initial_schema.js
│   │   ├── 002_add_job_execution_label.js
│   │   ├── 003_add_temp_image_path.js
│   │   └── index.js
│   ├── models
│   │   ├── GeneratedImage.js
│   │   ├── JobConfiguration.js
│   │   └── JobExecution.js
│   └── transactionManager.js
├── index.js
├── paramsGeneratorModule.js
├── producePictureModule.js
├── renderer
│   ├── App.jsx
│   ├── assets
│   │   ├── favicon
│   │   │   └── favicon.svg
│   │   ├── logo-square.svg
│   │   └── logo-zen.svg
│   ├── components
│   │   ├── Common
│   │   │   ├── AppLogo.tsx
│   │   │   ├── ConfirmResetDialog.tsx
│   │   │   ├── ExportDialog.tsx
│   │   │   ├── ExportFileModal.tsx
│   │   │   ├── SimpleDropdown.tsx
│   │   │   ├── StatusBadge.tsx
│   │   │   └── __tests__
│   │   │       └── ExportDialog.test.tsx
│   │   ├── Dashboard
│   │   │   ├── DashboardPanel.css
│   │   │   ├── DashboardPanel.tsx
│   │   │   ├── ExportZipModal.tsx
│   │   │   ├── FailedImageCard.tsx
│   │   │   ├── FailedImageModalContainer.tsx
│   │   │   ├── FailedImageReviewModal.css
│   │   │   ├── FailedImageReviewModal.tsx
│   │   │   ├── FailedImagesReviewPanel.tsx
│   │   │   ├── ForceStopButton.tsx
│   │   │   ├── ImageGallery.tsx
│   │   │   ├── ImageModal.tsx
│   │   │   ├── JobControls.tsx
│   │   │   ├── JobHistory.tsx
│   │   │   ├── LogViewer.tsx
│   │   │   ├── ProcessingSettingsModal.tsx
│   │   │   ├── ProgressIndicator.tsx
│   │   │   ├── QuickActions.tsx
│   │   │   ├── __tests__
│   │   │   │   ├── DashboardPanel.imageGallery.exportZip.moreCoverage.test.tsx
│   │   │   │   ├── DashboardPanel.test.tsx
│   │   │   │   ├── FailedImageCard.test.tsx
│   │   │   │   ├── FailedImageReviewModal.test.tsx
│   │   │   │   ├── FailedImagesReviewPanel.test.tsx
│   │   │   │   ├── ForceStopButton.test.tsx
│   │   │   │   ├── ImageGallery.test.tsx
│   │   │   │   ├── ImageModal.test.tsx
│   │   │   │   ├── JobControls.test.tsx
│   │   │   │   ├── JobHistory.test.tsx
│   │   │   │   ├── LogViewer.test.tsx
│   │   │   │   ├── ProcessingSettingsModal.test.tsx
│   │   │   │   ├── ProgressIndicator.test.tsx
│   │   │   │   └── QuickActions.test.tsx
│   │   │   └── index.ts
│   │   ├── Jobs
│   │   │   ├── BatchOperationsToolbar.tsx
│   │   │   ├── JobFilters.tsx
│   │   │   ├── JobManagementPanel.css
│   │   │   ├── JobManagementPanel.tsx
│   │   │   ├── JobStatistics.tsx
│   │   │   ├── JobTable.tsx
│   │   │   ├── SingleJobView.css
│   │   │   ├── SingleJobView.tsx
│   │   │   ├── __tests__
│   │   │   │   ├── BatchOperationsToolbar.test.tsx
│   │   │   │   ├── JobFilters.test.tsx
│   │   │   │   ├── JobLabelDisplay.test.tsx
│   │   │   │   ├── JobManagementPanel.workflows.moreCoverage.test.tsx
│   │   │   │   ├── JobStatistics.test.tsx
│   │   │   │   ├── JobTable.test.tsx
│   │   │   │   ├── SingleJobView.delete-refresh.test.tsx
│   │   │   │   ├── SingleJobView.edge-cases.test.tsx
│   │   │   │   ├── SingleJobView.pagination-filter.test.tsx
│   │   │   │   ├── SingleJobView.retryControls.persistence.test.tsx
│   │   │   │   ├── SingleJobView.settings-save.test.tsx
│   │   │   │   ├── SingleJobView.statistics.test.tsx
│   │   │   │   └── SingleJobView.test.tsx
│   │   │   └── index.ts
│   │   └── Settings
│   │       ├── ApiKeysSection.tsx
│   │       ├── CostIndicator.tsx
│   │       ├── FilePathsSection.tsx
│   │       ├── FileSelector.tsx
│   │       ├── ParametersSection.tsx
│   │       ├── SecureInput.tsx
│   │       ├── SettingsPanel.tsx
│   │       ├── SettingsSection.tsx
│   │       ├── Toggle.tsx
│   │       ├── __tests__
│   │       │   ├── ApiKeysSection.test.tsx
│   │       │   ├── CostIndicator.test.tsx
│   │       │   ├── FilePathsSection.test.tsx
│   │       │   ├── FileSelector.test.tsx
│   │       │   ├── Parameters.behavior.test.tsx
│   │       │   ├── ParametersSection.test.tsx
│   │       │   ├── RetryControls.persistence.test.tsx
│   │       │   ├── SecureInput.test.tsx
│   │       │   ├── SettingsPanel.robustness.moreCoverage.test.tsx
│   │       │   ├── SettingsPanel.test.tsx
│   │       │   ├── SettingsSection.test.tsx
│   │       │   └── Toggle.test.tsx
│   │       └── index.ts
│   ├── e2e
│   │   ├── E2EHarness.jsx
│   │   ├── PlatformHarness.jsx
│   │   └── ensureElectronStub.js
│   ├── index.css
│   ├── main.jsx
│   ├── types
│   │   ├── assets.d.ts
│   │   └── electron.d.ts
│   └── utils
│       ├── qc.ts
│       └── urls.ts
├── services
│   ├── errorTranslation.js
│   ├── jobRunner.js
│   └── retryExecutor.js
├── test
│   └── setup.ts
├── types
│   ├── database.d.ts
│   ├── errors.d.ts
│   ├── errors.js
│   ├── generatedImage.d.ts
│   ├── ipc.d.ts
│   ├── job.d.ts
│   ├── processing.d.ts
│   ├── progress.d.ts
│   └── settings.d.ts
├── utils
│   ├── logDebug.js
│   ├── logMasking.js
│   └── processing.js
└── utils.js

## Biggest Files by Line Count (Top 20)
- 56611  test-results.txt
- 18600  website/package-lock.json
- 16039  package-lock.json
-  4371  e2e-results.txt
-  3407  src/adapter/backendAdapter.js
-  3381  src/services/jobRunner.js
-  1910  docs/stories/1.9.critical-backend-fixes-and-technical-debt-resolution.story.md
-  1693  src/renderer/components/Jobs/SingleJobView.tsx
-  1661  src/renderer/components/Dashboard/DashboardPanel.tsx
-  1513  website/src/css/custom.css
-  1400  src/renderer/components/Settings/SettingsPanel.tsx
-  1349  src/renderer/components/Jobs/SingleJobView.css
-  1298  src/renderer/components/Dashboard/FailedImagesReviewPanel.tsx
-  1210  docs/architecture/testing-strategy.md
-  1173  src/renderer/components/Jobs/JobManagementPanel.tsx
-  1160  src/services/retryExecutor.js
-  1102  src/database/models/JobExecution.js
-  1027  tests/integration/backend/BackendAdapter.integration.test.ts
-  1003  src/database/models/GeneratedImage.js
-   956  docs/stories/1.4.configuration-implement-application-settings-ui.story.md

## Smallest Files (Line Count <= 900, Top 20 Smallest)
-     1  electron/renderer/assets/main-BWjRAo6F.css
-     1  release-notes-1.0.8.txt
-     6  nodemon.json
-     6  postcss.config.js
-     6  src/renderer/components/Jobs/index.ts
-     6  website/postcss.config.js
-     7  website/src/pages/markdown-page.md
-     9  src/renderer/components/Settings/index.ts
-    11  docs/prd/index.md
-    11  src/renderer/types/assets.d.ts
-    11  website/src/components/HomepageFeatures/styles.module.css
-    12  website/static/consent-mode.js
-    14  tsconfig.typecheck.json
-    15  docs/architecture/index.md
-    17  src/types/processing.d.ts
-    18  tailwind.config.js
-    19  docs/architecture/enhancement-scope-and-integration-strategy.md
-    19  docs/prd/next-steps.md
-    19  src/constant/defaultMetadataPrompt.js
-    20  src/renderer/main.jsx
