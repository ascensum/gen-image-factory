# rb-auto-midjourney-adobe-stock Brownfield Enhancement Architecture

## Sections

- [Introduction](./introduction.md)
- [Enhancement Scope and Integration Strategy](./enhancement-scope-and-integration-strategy.md)
- [Tech Stack Alignment](./tech-stack-alignment.md)
- [Data Models and Schema Changes](./data-models-and-schema-changes.md)
- [Component Architecture](./component-architecture.md)
- [Internal API Design](./internal-api-design.md)
- [Source Tree Integration](./source-tree-integration.md)
- [Infrastructure and Deployment Integration](./infrastructure-and-deployment-integration.md)
- [Testing Strategy and Standards](./testing-strategy.md)
- [Security Implementation Status](./security-implementation-status.md)
- [Next Steps](./next-steps.md)

## Architecture Decision Records (ADRs)

The following ADRs establish governance rules for the brownfield refactoring effort and **supersede any legacy patterns** found in the sharded architecture documents:

- [ADR-001: File Size Guardrail](./adr/ADR-001-File-Size-Guardrail.md) - 400-line limit and monolith governance (Master Frozen List)
- [ADR-002: Vertical Slice Architecture for IPC](./adr/ADR-002-Vertical-Slice-IPC.md) - Extracting IPC from BackendAdapter
- [ADR-003: Dependency Injection over Global State](./adr/ADR-003-DI-Pattern.md) - Eliminating global.backendAdapter
- [ADR-006: Solo-Developer Testing & Rollout Strategy](./adr/ADR-006-Solo-Developer-Testing-Rollout.md) - Feature toggles, shadow bridge pattern, and safe rollout workflow
- [ADR-007: CSS Standards - Tailwind-First Development](./adr/ADR-007-CSS-Standards.md) - Tailwind-First approach with 100-line CSS limit
- [ADR-008: Image Production Layer Extraction](./adr/ADR-008-Image-Production-Layer-Extraction.md) - Extracting producePictureModule into three domain services
- [ADR-009: Persistence Repository Layer](./adr/ADR-009-Persistence-Repository-Layer.md) - Extracting business logic from database models
- [ADR-010: Frontend Decomposition Standard](./adr/ADR-010-Frontend-Decomposition-Standard.md) - Breaking down monolithic React panels
- [ADR-011: Modular Testing Standard](./adr/ADR-011-Modular-Testing-Standard.md) - Deconstructing large integration test files
- [ADR-012: Retry Executor Decomposition](./adr/ADR-012-Retry-Executor-Decomposition.md) - Separating queue management from processing logic

**See also:** [Code Standards](../standards/CODE_STANDARDS.md) for enforcement rules. 