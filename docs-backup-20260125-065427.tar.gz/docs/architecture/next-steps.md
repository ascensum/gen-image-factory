# Next Steps

## CRITICAL: Epic 3 - Total Refactoring & Strangler Fig Migration

**Priority:** HIGHEST - Epic 3 is the mandatory prerequisite foundation before any new architecture work.

This architecture document provides the complete technical blueprint for the enhancement. **However, the current architecture is built on 12 monolithic files totaling ~16,000 lines that violate ADR-001 (400-line limit). Epic 3 must be completed to establish the modular foundation required for future development.**

### Epic 3 Overview

**Goal:** Systematically decompose all frozen monolithic files into modular, maintainable services following the Strangler Fig pattern with Shadow Bridge safety mechanisms.

**Scope:**
- 6 Backend/Services files (10,747 lines total)
- 4 Frontend Components (5,300 lines total)
- 1 Infrastructure/Tests file (1,000 lines)
- 1 Component Styling file (1,300 lines)

**Total Technical Debt:** ~16,000 lines of frozen monoliths

**Governance:** 10 ADRs (ADR-001 through ADR-012) define the complete refactoring strategy

### Architectural Principles (Epic 3)

**1. Strangler Fig Pattern (ADR-006)**
- Legacy code remains until new services are proven stable
- Zero-deletion policy during transition
- Feature toggles enable gradual, controlled migration

**2. Shadow Bridge Pattern (ADR-006)**
- Frozen monoliths act as routers to new services when enabled
- Bridge logic supports fallback to legacy if new service fails
- Mandatory testing: 100% coverage for bridge logic (both paths)

**3. Vertical Slice Architecture (ADR-002)**
- IPC handlers < 5 lines, delegate to services
- Clear separation: Controllers (IPC) → Services (business logic) → Repositories (persistence)
- Feature-based organization, not technical layers

**4. Dependency Injection (ADR-003)**
- All services accept dependencies in constructor
- No global state (`global.backendAdapter` forbidden)
- ServiceContainer in `electron/main.js` resolves dependencies at startup

**5. Buffer-Based Pipeline (ADR-008)**
- All image services accept Buffer and return Buffer
- Enables future dynamic pipeline ordering
- Testable without external dependencies

**6. Atomic Component Architecture (ADR-010)**
- View Layer (containers < 400 lines) - state management, API calls
- Component Layer (presentation < 400 lines) - pure presentation
- Hook Layer (logic < 400 lines) - reusable state logic

**7. Tailwind-First CSS (ADR-007)**
- 90% of styles as inline Tailwind utilities
- CSS Modules (< 100 lines) only for complex animations
- No component CSS files > 100 lines

**8. Repository Pattern (ADR-009)**
- Models < 200 lines (schema only)
- Repositories < 400 lines (query logic, business rules)
- Services depend on repositories, not models

**9. Modular Testing (ADR-011)**
- Test files < 400 lines (feature-based organization)
- Shared utilities extracted to `tests/integration/shared/`
- Tests can run in parallel (isolated databases)

**10. Retry Engine Decomposition (ADR-012)**
- RetryQueueService < 400 lines (queue management)
- RetryProcessorService < 400 lines (image processing)
- RetryExecutor < 200 lines (thin orchestrator)

### Implementation Roadmap

**Story 3.1: Backend Service Extraction (Weeks 1-4)**
- **Priority:** HIGHEST
- **Impact:** Unblocks all backend feature development
- **Deliverables:**
  - JobEngine (< 400 lines) - pure orchestration
  - JobService (< 400 lines) - persistence coordination
  - SecurityService (< 400 lines) - API key management
  - ExportService (< 400 lines) - Excel + ZIP generation
  - IPC Controllers (< 400 lines each) - JobController, SettingsController, ExportController, SecurityController
- **Feature Toggles:**
  - `FEATURE_MODULAR_JOB_ENGINE`
  - `FEATURE_MODULAR_JOB_SERVICE`
  - `FEATURE_MODULAR_SECURITY`
  - `FEATURE_MODULAR_EXPORT`
  - `FEATURE_MODULAR_IPC_CONTROLLERS`

**Story 3.2: Persistence Repository Layer (Weeks 5-7)**
- **Priority:** HIGH
- **Impact:** Enables clean data access layer and database migrations
- **Deliverables:**
  - JobRepository (< 400 lines)
  - ImageRepository (< 400 lines)
  - JobConfigurationRepository (< 400 lines)
  - JobExecution.js reduced to < 200 lines (schema only)
  - GeneratedImage.js reduced to < 200 lines (schema only)
- **Feature Toggles:**
  - `FEATURE_MODULAR_JOB_REPOSITORY`
  - `FEATURE_MODULAR_IMAGE_REPOSITORY`
  - `FEATURE_MODULAR_CONFIG_REPOSITORY`

**Story 3.3: Image Production Pipeline (Weeks 8-9)**
- **Priority:** MEDIUM
- **Impact:** Prepares for future dynamic pipeline architecture
- **Deliverables:**
  - ImageGeneratorService (< 400 lines) - Runware API
  - ImageRemoverService (< 400 lines) - remove.bg + alpha trim
  - ImageProcessorService (< 400 lines) - Sharp manipulation
- **Feature Toggles:**
  - `FEATURE_MODULAR_GENERATOR`
  - `FEATURE_MODULAR_REMOVER`
  - `FEATURE_MODULAR_PROCESSOR`

**Story 3.4: Atomic React Panel Decomposition (Weeks 10-13)**
- **Priority:** HIGH
- **Impact:** Enables maintainable frontend and UI feature development
- **Deliverables:**
  - DashboardView + components + hooks (all < 400 lines)
  - SettingsView + components + hooks (all < 400 lines)
  - FailedImagesReviewView + components + hooks (all < 400 lines)
  - JobManagementView + components + hooks (all < 400 lines)
  - SingleJobView.css → Tailwind-First (90% inline, CSS Module < 100 lines)

**Story 3.5: Retry Engine & Test Modularization (Weeks 14-15)**
- **Priority:** MEDIUM
- **Impact:** Clean retry mechanism and modular test suite
- **Deliverables:**
  - RetryQueueService (< 400 lines)
  - RetryProcessorService (< 400 lines)
  - RetryExecutor (< 200 lines)
  - Feature-based integration test suites (all < 400 lines)
- **Feature Toggles:**
  - `FEATURE_MODULAR_RETRY_QUEUE`
  - `FEATURE_MODULAR_RETRY_PROCESSOR`

### Architecture Success Metrics

**Before Epic 3 is complete:**
- [ ] All 12 frozen files decomposed
- [ ] 100% of source files < 400 lines
- [ ] Zero global state (`global.backendAdapter` eliminated)
- [ ] All services use dependency injection
- [ ] IPC handlers < 5 lines (100% compliance)
- [ ] ≥70% test coverage for new services
- [ ] 100% test coverage for bridge logic
- [ ] All feature toggles enabled in production
- [ ] All Phase 5 cleanups complete (bridges removed)
- [ ] Architecture diagrams updated

### Technical Risk Mitigation

**Risk:** Circular dependencies during extraction
- **Mitigation:** Strict dependency injection (ADR-003), interface segregation, ServiceContainer resolution

**Risk:** Bridge complexity adds technical debt
- **Mitigation:** Time-bounded toggles (2-3 releases), mandatory Phase 5 cleanup, code review checklist

**Risk:** Test coverage regression
- **Mitigation:** Mandatory coverage gates (≥70% services, 100% bridge), CI enforcement

**Risk:** Production incidents during rollout
- **Mitigation:** Phased rollout, easy rollback via toggles, immutable safety net

### Blocking Dependencies

**Epic 1 Feature Development:**
- **BLOCKED** until Stories 3.1 and 3.2 are complete
- Reason: New features would require modifying frozen files (governance violation)

**Epic 2 Documentation Website:**
- **UNBLOCKED** - can proceed in parallel
- Reason: No modifications to frozen files required

---

## Legacy Architecture Priorities (Pre-Epic 3)

## Security Implementation Priorities

### **Story 1.13: Security Hardening (Future Enhancement)**
- **Encrypted Database Fallback**: Implement encrypted database storage when keytar is unavailable
- **Memory Protection**: Add comprehensive memory protection for sensitive data
- **Log Masking**: Implement secure logging that masks API keys and sensitive information
- **Security Monitoring**: Add security health checks and monitoring capabilities

### **Current Security Status (Story 1.2 Complete)**
- ✅ **Native OS Keychain**: Primary secure storage using keytar
- ✅ **Security Status Communication**: UI displays current security level and storage method
- ✅ **Fallback Mechanism**: Graceful fallback to plain text storage (development mode)
- ✅ **User Messaging**: Clear communication about security implications

### **Security Testing Requirements**
- **Unit Testing**: Complete security method testing with 100% coverage
- **Integration Testing**: Cross-platform security validation
- **End-to-End Testing**: Security UI behavior across different platforms
- **Performance Testing**: Security operations performance validation

## Implementation Roadmap

### **Immediate Priorities**
1. ✅ **Story 1.5**: Core Controls UI - Implement job control interface (COMPLETE)
2. ✅ **Story 1.6**: Results Gallery - Successful results view with Excel export (COMPLETE)
3. **Story 1.7**: Failed Images Review - Manual approval workflow for failed images
4. **Story 1.14**: Test Stabilization – Unit & Integration
5. **Story 1.8**: Job History - Database integration for job history and persistence
6. **Story 1.12**: Advanced Export & File Management - ZIP+Excel export and file operations

### **CI/CD & DevSecOps (Architectural Deliverables)**
1. Add local pre-commit gate (fast): `.husky/pre-commit` running ESLint (no warnings), `npm run test:critical`, Semgrep (OWASP Top 10 + JS), optional `npm audit --omit=dev`.
2. Add cloud QA (GitHub Actions): `.github/workflows/ci.yml` with build, tests, CodeQL, Semgrep, audit on push to `main`.
3. Semgrep configuration: Uses command-line flags (`--config=p/owasp-top-ten --config=p/javascript`) due to Semgrep 1.146.0 YAML config compatibility limitation. Path exclusions via `.semgrepignore`. **Note**: `p/owasp-electron` does not exist; `p/owasp-top-ten` covers Electron security concerns.
4. Optional: release build on tags with `electron-builder --publish never` and upload artifacts to release draft.
5. Refinements: CI concurrency (cancel in-progress), Semgrep excludes via `.semgrepignore`, weekly scheduled CodeQL.
6. Automated release pipeline (Story 1.21): Triggered by Git Tags (`v*.*.*`) automatically builds `electron-builder` artifacts and uploads to GitHub Releases; Windows uses Microsoft Store (mandatory) with MSIX packages; GitHub Releases (secondary, unsigned) for advanced users; macOS/Linux use GitHub Releases with `electron-updater` for automatic updates; SHA-256 checksums and SBOM required for every release.

### **Security Enhancement Path**
1. **Story 1.13**: Security Hardening - Encrypted database and memory protection
2. **Security Monitoring**: Add security health checks and alerts
3. **Advanced Security**: Key rotation and advanced security features (if needed)

### **Quality Assurance**
1. **Security Testing**: Comprehensive security testing across all platforms
2. **Performance Testing**: Security operations performance validation
3. **User Experience**: Security status communication and user feedback

## Risk Mitigation

### **Security Risks**
- **Keytar Failures**: Robust fallback mechanisms in place
- **Cross-Platform Issues**: Comprehensive testing across target platforms
- **User Communication**: Clear messaging about security implications

### **Development Risks**
- **Performance Impact**: Security operations optimized for minimal overhead
- **User Experience**: Security features integrated seamlessly into UI
- **Maintenance**: Security code well-documented and maintainable

## Success Criteria

### **Security Success Metrics**
- ✅ Secure storage available on all target platforms
- ✅ Graceful fallback when secure storage unavailable
- ✅ Clear user communication about security status
- ✅ No sensitive data exposed in logs or error messages
- ✅ Security operations complete within acceptable performance limits 