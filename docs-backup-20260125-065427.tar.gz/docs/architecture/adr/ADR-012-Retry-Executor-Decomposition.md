# ADR-012: Retry Executor Decomposition

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** retry, queue-management, service-decomposition

## Context

`retryExecutor.js` (1,160 lines) is a service that handles post-processing retry for failed images. While it's already a focused service (not a monolith like `jobRunner.js` or `backendAdapter.js`), it exceeds the 400-line limit (ADR-001) and combines multiple responsibilities.

**Current Responsibilities:**
1. **Queue Management:** Batch retry job queuing, queue processing, status tracking
2. **Image Processing:** Orchestrates `processImage()` calls for failed images
3. **Metadata Regeneration:** Orchestrates `aiVision` calls for metadata
4. **Database Operations:** Updates `GeneratedImage` records with new statuses and paths
5. **Event Emission:** Progress tracking and status updates via EventEmitter

**Problems:**
- **Exceeds Size Limit:** 1,160 lines violates ADR-001 (400-line limit)
- **Multiple Responsibilities:** Queue management, processing orchestration, and database operations
- **Tight Coupling:** Directly depends on `processImage`, `aiVision`, and database models
- **Hard to Test:** Cannot test queue logic without image processing dependencies

## Decision

We decompose `retryExecutor.js` into **two focused services** following the Single Responsibility Principle:

### 1. Service Boundaries

#### RetryQueueService
**Responsibility:** Queue management and job orchestration  
**Extracted from:** Lines ~19-340 (queue management, job creation, status tracking)  
**Interface:**
```javascript
class RetryQueueService {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
  }
  
  async addBatchRetryJob(batchRetryJob) { }
  async processQueue() { }
  clearQueue() { }
  stopProcessing() { }
  getQueueStatus() { }
}
```

**Responsibilities:**
- Queue management (add, remove, clear)
- Job status tracking (pending, processing, completed, failed)
- Queue processing orchestration
- Event emission for queue updates

#### RetryProcessorService
**Responsibility:** Individual image retry processing  
**Extracted from:** Lines ~350-1150 (image processing, metadata regeneration, database updates)  
**Dependencies:** Injected via constructor (ADR-003)
- `ImageProcessorService` (from ADR-008) - for image processing
- `ImageRepository` (from ADR-009) - for database operations
- `MetadataService` (future) - for metadata regeneration

**Interface:**
```javascript
class RetryProcessorService {
  constructor(imageProcessor, imageRepository, metadataService) {
    this.imageProcessor = imageProcessor;
    this.imageRepository = imageRepository;
    this.metadataService = metadataService;
  }
  
  async processSingleImage(job) {
    // 1. Get image from repository
    // 2. Process image via ImageProcessorService
    // 3. Regenerate metadata if needed
    // 4. Update database via ImageRepository
    // 5. Return result
  }
}
```

**Responsibilities:**
- Single image retry processing
- Settings resolution (original vs modified)
- Image processing orchestration
- Metadata regeneration
- Database status updates

### 2. Integration Pattern

**RetryExecutor (Thin Orchestrator):**
```javascript
class RetryExecutor extends EventEmitter {
  constructor(options = {}) {
    super();
    this.queueService = new RetryQueueService();
    this.processorService = new RetryProcessorService(
      options.imageProcessor,
      options.imageRepository,
      options.metadataService
    );
    
    // Wire queue service events
    this.queueService.on('queue-updated', (data) => this.emit('queue-updated', data));
    this.queueService.on('job-status-updated', (data) => this.emit('job-status-updated', data));
  }
  
  async addBatchRetryJob(batchRetryJob) {
    return await this.queueService.addBatchRetryJob(batchRetryJob);
  }
  
  async processQueue() {
    const jobs = this.queueService.getPendingJobs();
    for (const job of jobs) {
      const result = await this.processorService.processSingleImage(job);
      this.queueService.updateJobStatus(job.id, result.success ? 'completed' : 'failed');
    }
  }
}
```

**Target:** RetryExecutor becomes < 200 lines (thin orchestrator)

### 3. Migration Strategy

**Phase 1: Extract RetryQueueService**
1. Create `src/services/RetryQueueService.js`
2. Move queue management logic
3. Add Vitest unit tests (≥70% coverage)
4. Target: < 400 lines

**Phase 2: Extract RetryProcessorService**
1. Create `src/services/RetryProcessorService.js`
2. Move image processing logic
3. Inject dependencies (ImageProcessorService, ImageRepository)
4. Add Vitest unit tests (≥70% coverage)
5. Target: < 400 lines

**Phase 3: Refactor RetryExecutor**
1. Refactor to thin orchestrator
2. Wire services together
3. Maintain EventEmitter interface for backward compatibility
4. Target: < 200 lines

**Phase 4: Integration**
1. Update `BackendAdapter` to use new structure
2. Update tests
3. Verify functionality

### 4. Feature Flag (ADR-006)

**Feature Flag:** `FEATURE_MODULAR_RETRY`

**Bridge Pattern:**
```javascript
// In retryExecutor.js (Frozen)
class RetryExecutor {
  constructor(options = {}) {
    if (process.env.FEATURE_MODULAR_RETRY === 'true') {
      this.queueService = new RetryQueueService();
      this.processorService = new RetryProcessorService(...);
    } else {
      // Legacy implementation (current code)
    }
  }
}
```

### 5. Testing Requirements

**RetryQueueService Tests:**
- Queue management (add, remove, clear)
- Job status tracking
- Queue processing logic
- Event emission

**RetryProcessorService Tests:**
- Image processing orchestration
- Settings resolution
- Database updates
- Error handling

**Integration Tests:**
- Full retry workflow
- Event propagation
- Database persistence

## Consequences

### Positive
- **Separation of Concerns:** Queue management separate from processing logic
- **Testability:** Services can be tested independently
- **Compliance:** All services meet 400-line limit (ADR-001)
- **Better Integration:** Uses extracted services (ImageProcessorService, ImageRepository)
- **Maintainability:** Smaller, focused services

### Negative
- **Initial Refactoring:** Requires careful extraction
- **More Files:** Two services instead of one
- **Migration Overhead:** Must update BackendAdapter integration

### Migration Example

**Before (Monolithic Service):**
```javascript
// RetryExecutor.js (1,160 lines)
class RetryExecutor extends EventEmitter {
  constructor() {
    this.queue = [];
    // ... 1,150 more lines combining queue + processing
  }
  
  async processSingleImage(job) {
    // 200 lines of processing logic
  }
}
```

**After (Decomposed):**
```javascript
// RetryQueueService.js (< 400 lines)
class RetryQueueService extends EventEmitter {
  constructor() {
    this.queue = [];
  }
  
  async addBatchRetryJob(batchRetryJob) { }
  async processQueue() { }
}

// RetryProcessorService.js (< 400 lines)
class RetryProcessorService {
  constructor(imageProcessor, imageRepository) {
    this.imageProcessor = imageProcessor;
    this.imageRepository = imageRepository;
  }
  
  async processSingleImage(job) {
    // Processing logic using injected services
  }
}

// RetryExecutor.js (< 200 lines)
class RetryExecutor extends EventEmitter {
  constructor(options) {
    this.queueService = new RetryQueueService();
    this.processorService = new RetryProcessorService(...);
  }
}
```

## Related ADRs
- ADR-001: File Size Guardrail (400-line limit)
- ADR-003: Dependency Injection over Global State
- ADR-006: Solo-Developer Testing & Rollout Strategy (feature flags)
- ADR-008: Image Production Layer Extraction (ImageProcessorService)
- ADR-009: Persistence Repository Layer (ImageRepository)

## References
- Single Responsibility Principle (SOLID)
- [Service Decomposition](https://martinfowler.com/articles/break-monolith-into-microservices.html)
