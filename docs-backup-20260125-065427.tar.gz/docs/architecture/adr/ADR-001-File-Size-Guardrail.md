# ADR-001: File Size Guardrail

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** modularity, maintainability, code-quality

## Context

The codebase contains monolithic files that violate the Single Responsibility Principle:
- `jobRunner.js`: 3,381 lines
- `backendAdapter.js`: 3,407 lines

**Additional High-Debt Files Identified:**
- Backend/Services: `src/services/retryExecutor.js` (1,100 lines), `src/database/models/JobExecution.js` (1,100 lines), `src/database/models/GeneratedImage.js` (1,000 lines)
- Frontend Components: `src/renderer/components/Dashboard/DashboardPanel.tsx` (1,600 lines), `src/renderer/components/Settings/SettingsPanel.tsx` (1,400 lines), `src/renderer/components/Dashboard/FailedImagesReviewPanel.tsx` (1,200 lines), `src/renderer/components/Jobs/JobManagementPanel.tsx` (1,100 lines)
- Infrastructure/Tests: `tests/integration/backend/BackendAdapter.integration.test.ts` (1,000 lines)
- Component Styling: `src/renderer/components/Jobs/SingleJobView.css` (1,300 lines)

These files have become "God Classes" that:
- Hoard multiple responsibilities (database operations, IPC routing, business logic, file I/O)
- Are difficult to test in isolation
- Create circular dependencies (JobRunner ↔ BackendAdapter via global state)
- Reduce code readability and maintainability
- Make refactoring risky and time-consuming

Files exceeding 400 lines become cognitively unmanageable and indicate architectural violations.

## Decision

We establish a **hard limit of 400 lines per file** as a governance guardrail:

1. **Strict Limit Enforcement:**
   - CI/Linting will warn on files > 400 lines
   - Pre-commit hooks will flag violations
   - Code review must reject PRs that introduce files > 400 lines

2. **Mitigation Strategy:**
   - If a Service exceeds 400 lines, it **must** be split by feature/responsibility
   - Example: `JobRunner.js` → `JobInitializer.js`, `JobExecutor.js`, `JobFinalizer.js`
   - Split by domain boundaries, not arbitrary line counts

3. **Legacy File Treatment:**
   - Existing files > 400 lines are **frozen** (no new logic may be added)
   - New features must extract to new Services/Repositories
   - Legacy files are subject to "Strangler Fig" pattern: gradually extract functionality until they become thin facades

4. **Exemptions:**
   - Generated code (e.g., migration files, auto-generated types) are exempt
   - Test files may exceed 400 lines only if they cover a single, cohesive test suite
   - Configuration files (JSON, YAML) are exempt

## Consequences

### Positive
- **Improved Maintainability:** Smaller files are easier to understand and modify
- **Better Testability:** Isolated services can be unit tested independently
- **Reduced Coupling:** Forces explicit dependency injection instead of global state
- **Faster Onboarding:** New developers can understand codebase structure more quickly
- **Composition over Inheritance:** Encourages building complex behavior from small, focused modules

### Negative
- **Initial Refactoring Overhead:** Existing monoliths require extraction work
- **More Files:** Codebase will have more files, but better organized
- **Dependency Management:** Requires explicit DI pattern (see ADR-003)

### Migration Path
1. **Phase 1 (Immediate):** Freeze all files on the Master Frozen List - no new logic
2. **Phase 2 (Extraction):** Extract services per ADR-002 and ADR-003
3. **Phase 3 (Strangler):** Gradually move logic from monoliths to new services
4. **Phase 4 (Removal):** Once monoliths are thin facades, remove them entirely

## Master Frozen List

The following files are **FROZEN** (no new logic may be added) and subject to the Strangler Fig pattern:

### Backend/Services
- `src/services/jobRunner.js` (3,381 lines)
- `src/adapter/backendAdapter.js` (3,407 lines)
- `src/producePictureModule.js` (799 lines) - *Image Production Layer - extraction planned (see ADR-008)*
- `src/services/retryExecutor.js` (1,160 lines) - *Extraction: ADR-012 (Retry Executor Decomposition)*
- `src/database/models/JobExecution.js` (1,100 lines) - *Business logic must move to Repository Layer*
- `src/database/models/GeneratedImage.js` (1,000 lines) - *Business logic must move to Repository Layer*

### Frontend Components
- `src/renderer/components/Dashboard/DashboardPanel.tsx` (1,600 lines)
- `src/renderer/components/Settings/SettingsPanel.tsx` (1,400 lines)
- `src/renderer/components/Dashboard/FailedImagesReviewPanel.tsx` (1,200 lines)
- `src/renderer/components/Jobs/JobManagementPanel.tsx` (1,100 lines)

### Infrastructure/Tests
- `tests/integration/backend/BackendAdapter.integration.test.ts` (1,000 lines)

### Component Styling
- `src/renderer/components/Jobs/SingleJobView.css` (1,300 lines) - *Must refactor to Tailwind (see ADR-007)*

**Note:** Database models (`JobExecution.js`, `GeneratedImage.js`) should be reduced to < 200 lines containing only Sequelize/SQLite schema definitions. All query logic, hooks, and instance methods must move to the Repository Layer (e.g., `src/repositories/JobRepository.js`).

## Related ADRs
- ADR-002: Vertical Slice Architecture for IPC
- ADR-003: Dependency Injection over Global State
- ADR-006: Solo-Developer Testing & Rollout Strategy (feature flags, bridge pattern)
- ADR-007: CSS Standards - Tailwind-First Development
- ADR-008: Image Production Layer Extraction
- ADR-009: Persistence Repository Layer (database model extraction)
- ADR-010: Frontend Decomposition Standard (React panel decomposition)
- ADR-011: Modular Testing Standard (test file decomposition)
- ADR-012: Retry Executor Decomposition (queue and processor separation)

## References
- [Strangler Fig Pattern](https://martinfowler.com/bliki/StranglerFigApplication.html)
- Single Responsibility Principle (SOLID)
- [Cognitive Load Theory in Software Development](https://www.infoq.com/articles/cognitive-load/)
