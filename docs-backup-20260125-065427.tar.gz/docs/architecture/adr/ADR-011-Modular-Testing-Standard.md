# ADR-011: Modular Testing Standard

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** testing, test-organization, modularity, quality-assurance

## Context

The test suite contains monolithic integration test files that violate testing best practices:
- `BackendAdapter.integration.test.ts` (1,000 lines)

**Problems:**
- **Test Bloat:** Single test file covers multiple features and concerns
- **Hard to Navigate:** Finding specific test cases requires scrolling through 1,000+ lines
- **Slow Execution:** Large test files take longer to run and debug
- **Poor Maintainability:** Changes to one feature require editing massive files
- **Violates Size Limit:** Test file exceeds 400-line limit (ADR-001 exemption requires single cohesive suite, but this file covers multiple features)

**Current State:**
- Integration tests combine multiple feature areas (settings, jobs, images, exports)
- Test setup and teardown logic duplicated across test cases
- No clear organization by feature domain
- Difficult to run focused test subsets

## Decision

We decompose monolithic integration test files into **feature-based test suites** following a modular testing organization.

### 1. Target Architecture

**Feature-Based Test Organization:**
- **Location:** `tests/integration/[feature]/`
- **Structure:** One test file per feature domain
- **Size Limit:** < 400 lines per test file (ADR-001)
- **Pattern:** Co-located with feature code when possible

**Test Suite Structure:**
```
tests/
├── integration/
│   ├── settings/
│   │   ├── SettingsAdapter.integration.test.ts (< 400 lines)
│   │   └── ApiKeys.integration.test.ts (< 400 lines)
│   ├── jobs/
│   │   ├── JobExecution.integration.test.ts (< 400 lines)
│   │   ├── JobRunner.integration.test.ts (< 400 lines)
│   │   └── JobRepository.integration.test.ts (< 400 lines)
│   ├── images/
│   │   ├── ImageRepository.integration.test.ts (< 400 lines)
│   │   └── ImageProcessing.integration.test.ts (< 400 lines)
│   ├── exports/
│   │   ├── ExcelExport.integration.test.ts (< 400 lines)
│   │   └── ZipExport.integration.test.ts (< 400 lines)
│   └── adapter/
│       └── BackendAdapter.bridge.integration.test.ts (< 400 lines)
```

### 2. Decomposition Strategy

#### BackendAdapter.integration.test.ts (1,000 lines → Multiple Files)

**Extract by Feature Domain:**

1. **Settings Integration Tests:**
   - `tests/integration/settings/SettingsAdapter.integration.test.ts`
   - Covers: API keys, file paths, settings persistence
   - Target: < 400 lines

2. **Job Execution Tests:**
   - `tests/integration/jobs/JobExecution.integration.test.ts`
   - Covers: Job start/stop, status tracking, execution history
   - Target: < 400 lines

3. **Image Management Tests:**
   - `tests/integration/images/ImageManagement.integration.test.ts`
   - Covers: Image saving, retrieval, QC status updates
   - Target: < 400 lines

4. **Export Functionality Tests:**
   - `tests/integration/exports/ExportOperations.integration.test.ts`
   - Covers: Excel export, ZIP export, bulk operations
   - Target: < 400 lines

5. **Bridge Integration Tests:**
   - `tests/integration/adapter/BackendAdapter.bridge.integration.test.ts`
   - Covers: Feature flag routing, legacy/new path verification
   - Target: < 400 lines

### 3. Test Organization Principles

**Feature Cohesion:**
- Tests grouped by feature domain, not by implementation
- Related test cases in same file
- Clear test file naming: `[Feature].[aspect].integration.test.ts`

**Shared Test Utilities:**
- **Location:** `tests/integration/shared/`
- **Content:** Common setup, mocks, helpers
- **Files:**
  - `test-setup.ts` - Database initialization, mocks
  - `test-helpers.ts` - Utility functions
  - `test-fixtures.ts` - Test data factories

**Test Isolation:**
- Each test file uses isolated test database
- No shared state between test files
- Tests can run in parallel

### 4. Test File Size Standards

**Integration Test Files:**
- **Limit:** < 400 lines per file (ADR-001)
- **Content:** Test cases for single feature domain
- **Structure:**
  ```typescript
  describe('[Feature] Integration', () => {
    beforeEach(() => {
      // Setup (isolated database, mocks)
    });
    
    describe('Specific Aspect', () => {
      it('should test specific behavior', () => { });
    });
  });
  ```

**Shared Utilities:**
- **Limit:** < 400 lines per utility file
- **Content:** Reusable test setup and helpers
- **No Test Cases:** Only utilities and setup code

### 5. Migration Strategy

**Phase 1: Extract Shared Utilities**
1. Create `tests/integration/shared/` directory
2. Extract common setup to `test-setup.ts`
3. Extract helpers to `test-helpers.ts`
4. Extract fixtures to `test-fixtures.ts`

**Phase 2: Decompose by Feature**
1. Create feature directories (`settings/`, `jobs/`, `images/`, `exports/`)
2. Extract test cases by feature domain
3. Ensure each file < 400 lines
4. Add comprehensive test coverage

**Phase 3: Update Test Scripts**
1. Add feature-specific test scripts:
   - `npm run test:integration:settings`
   - `npm run test:integration:jobs`
   - `npm run test:integration:images`
   - `npm run test:integration:exports`
2. Update CI to run all integration test suites

**Phase 4: Verify & Document**
1. Ensure all test files < 400 lines
2. Verify test coverage maintained
3. Update testing documentation

### 6. Testing Requirements

**Test Coverage:**
- **Maintain:** ≥70% statement and branch coverage (per ADR-006)
- **Verify:** Coverage not reduced by decomposition
- **Track:** Coverage per feature domain

**Test Execution:**
- **Parallel Execution:** Tests can run in parallel (isolated databases)
- **Focused Testing:** Can run single feature test suite
- **CI Integration:** All test suites run in CI pipeline

**Test Quality:**
- **Isolation:** No shared state between tests
- **Deterministic:** Tests produce consistent results
- **Fast:** Decomposed tests run faster (parallel execution)

## Consequences

### Positive
- **Maintainability:** Smaller test files are easier to navigate and modify
- **Focused Testing:** Can run tests for specific features
- **Faster Execution:** Parallel test execution possible
- **Better Organization:** Tests organized by feature domain
- **Compliance:** All test files meet 400-line limit (ADR-001)

### Negative
- **Initial Refactoring:** Requires careful extraction to maintain coverage
- **More Files:** Decomposition creates more test files
- **Migration Overhead:** Must update test scripts and CI configuration

### Migration Example

**Before (Monolithic Test File):**
```typescript
// BackendAdapter.integration.test.ts (1,000 lines)
describe('BackendAdapter Integration', () => {
  // 200 lines of setup
  
  describe('Settings', () => {
    // 200 lines of settings tests
  });
  
  describe('Jobs', () => {
    // 200 lines of job tests
  });
  
  describe('Images', () => {
    // 200 lines of image tests
  });
  
  describe('Exports', () => {
    // 200 lines of export tests
  });
});
```

**After (Feature-Based Decomposition):**
```typescript
// tests/integration/settings/SettingsAdapter.integration.test.ts (< 400 lines)
import { setupTestDatabase } from '../shared/test-setup';

describe('Settings Integration', () => {
  beforeEach(() => {
    setupTestDatabase();
  });
  
  describe('API Keys', () => {
    // Focused test cases
  });
  
  describe('File Paths', () => {
    // Focused test cases
  });
});

// tests/integration/jobs/JobExecution.integration.test.ts (< 400 lines)
import { setupTestDatabase } from '../shared/test-setup';

describe('Job Execution Integration', () => {
  beforeEach(() => {
    setupTestDatabase();
  });
  
  describe('Job Lifecycle', () => {
    // Focused test cases
  });
});
```

## Related ADRs
- ADR-001: File Size Guardrail (400-line limit)
- ADR-006: Solo-Developer Testing & Rollout Strategy
- ADR-009: Persistence Repository Layer (repository tests)

## References
- [Testing Best Practices](https://testingjavascript.com/)
- [Test Organization](https://kentcdodds.com/blog/test-isolation-with-react)
- [Vitest Documentation](https://vitest.dev/guide/organizing-tests.html)
