# ADR-013: Local Obsidian & Remote Qdrant Bridge

**Status:** Accepted  
**Date:** 2026-01-24  
**Deciders:** Architecture Team  
**Tags:** knowledge-management, ai-assisted-development, developer-experience, architecture

## Context

During **Epic 3** (Long-Horizon Refactoring), AI agents face the **"Context Decay"** problem when executing multi-week brownfield refactoring stories:

1. **Knowledge Fragmentation:**
   - 12 ADRs define architectural constraints (frozen files, DI patterns, IPC limits)
   - Multiple PRD shards, coding standards, tech stack documentation
   - Story execution logs and refactoring progress notes
   - This knowledge is spread across 40+ markdown files

2. **Context Window Limitations:**
   - Agents cannot load entire project documentation on every interaction
   - Critical architectural constraints must be retrieved semantically, not manually attached
   - Repetitive context loading wastes tokens and developer time

3. **Documentation Workflow Friction:**
   - Developers want to edit docs in **Obsidian** (knowledge graph, backlinks, visual editing)
   - But the codebase repo needs docs for IDE visibility and version control
   - Duplicating documentation across tools creates sync problems

4. **Memory Persistence:**
   - Agent memory should outlive individual chat sessions
   - Knowledge should be queryable across multiple projects (portfolio-wide memory)
   - Semantic search must work across ADRs, stories, and technical documentation

**The Core Problem:**  
How do we provide AI agents with **on-demand, semantic access** to project knowledge while maintaining a **developer-friendly documentation workflow** that integrates with both IDE and Obsidian?

## Decision

We implement a **Local Obsidian + Remote Qdrant Bridge** architecture using **symbolic links** and **Model Context Protocol (MCP)** integration.

### 1. Architecture Overview

**Source of Truth:** Local Obsidian Vault (outside repo)

**Integration Pattern:**
```
┌──────────────────────┐
│  Obsidian Vault      │  ← Source of Truth (human editing)
│  ~/Documents/Vault/  │     ADRs, PRDs, Stories, Standards
└──────────┬───────────┘
           │ symlink (ln -s)
┌──────────▼───────────┐
│  ./docs (repo)       │  ← IDE visibility (version control)
└──────────┬───────────┘
           │ manual ingestion
┌──────────▼───────────┐
│  Qdrant Instance     │  ← Separate repo: bmad-qdrant-knowledge-management
│  (Remote/Cloud)      │     Vector embeddings + semantic search
└──────────┬───────────┘
           │ MCP (stdio transport)
┌──────────▼───────────┐
│  AI Agents (Cursor)  │  ← Context-aware development
└──────────────────────┘
```

### 2. Component Definitions

#### Component 1: Obsidian Vault (Source of Truth)

**Location:** Local file system outside repository (e.g., `~/Documents/Obsidian/BMad-Projects/`)

**Responsibility:**
- Primary editing environment for all documentation
- Knowledge graph visualization (backlinks, graph view)
- Human-friendly browsing and organization
- Rich markdown features (callouts, dataview, tags)

**Structure:**
```
~/Documents/Obsidian/BMad-Projects/
├── gen-image-factory/
│   ├── adr/
│   │   ├── ADR-001-File-Size-Guardrail.md
│   │   ├── ADR-002-Vertical-Slice-IPC.md
│   │   └── ...
│   ├── prd/
│   ├── stories/
│   └── standards/
└── other-projects/
```

**Key Benefit:** Obsidian features work across multiple projects (cross-project backlinks, unified search).

#### Component 2: Repository Symlink (./docs)

**Location:** `./docs` in repository root

**Implementation:**
```bash
# One-time setup per developer
ln -s ~/Documents/Obsidian/BMad-Projects/gen-image-factory ./docs
```

**Responsibility:**
- IDE visibility (Cursor can read/edit documentation)
- Version control (Git tracks changes via symlink)
- Agent access (agents read from ./docs during sessions)

**Git Configuration:**
```gitignore
# .gitignore - Do NOT ignore ./docs symlink
# Git will track symlink target changes automatically
```

**Key Benefit:** Single source of truth (Obsidian) visible in both IDE and Obsidian GUI.

#### Component 3: Qdrant Instance (Separate Repository)

**Repository:** `https://github.com/Hidden-History/bmad-qdrant-knowledge-management`

**Deployment Options:**
1. **Qdrant Cloud** (recommended for persistent memory)
2. **Self-hosted Docker** (for privacy-sensitive projects)

**Collections Structure:**
- `gen-image-factory-architecture` - ADRs, tech stack, source tree
- `gen-image-factory-requirements` - PRD shards, epic documents
- `gen-image-factory-stories` - Execution logs, migration notes
- `gen-image-factory-standards` - Code standards, testing guidelines

**Ingestion Pipeline:**
- **Location:** Managed in separate `bmad-qdrant-knowledge-management` repo
- **Trigger:** Manual (`npm run ingest:gen-image-factory`) or webhook
- **Process:**
  1. Scans Obsidian vault directory
  2. Parses markdown frontmatter for metadata
  3. Chunks documents (512 tokens, 50 token overlap)
  4. Generates embeddings (OpenAI `text-embedding-3-small`)
  5. Upserts to Qdrant with metadata (file_path, document_type, tags, last_modified)

**Key Benefit:** Memory persists across projects and machines. Portfolio-wide semantic search.

#### Component 4: MCP Integration (Model Context Protocol)

**Protocol:** stdio transport mode

**Configuration:** `.cursor/mcp_config.json` (Cursor IDE)
```json
{
  "mcpServers": {
    "bmad-qdrant": {
      "command": "node",
      "args": [
        "/path/to/bmad-qdrant-knowledge-management/mcp-server.js"
      ],
      "env": {
        "QDRANT_URL": "https://your-cluster.qdrant.io",
        "QDRANT_API_KEY": "***",
        "QDRANT_COLLECTION_PREFIX": "gen-image-factory"
      }
    }
  }
}
```

**MCP Tools Provided:**
- `query_memory(query, collection, limit)` - Semantic search across knowledge base
- `ingest_document(file_path, metadata)` - Index new documents
- `list_collections()` - Show available knowledge collections

**Agent Workflow:**
```javascript
// Example: Agent starting ADR-009 Repository Layer extraction
const context = await mcp.invoke('query_memory', {
  query: "database models persistence layer repository pattern frozen files",
  collection: "gen-image-factory-architecture",
  limit: 3
});
// Returns: ADR-009, ADR-001, ADR-003 with excerpts and scores
```

**Key Benefit:** Agents query memory declaratively without managing vector DB connections.

### 3. Governance Rules (BMAD_INTEGRATION_RULES)

**Rule 1: Query Before Refactoring**
- **Requirement:** All agents MUST query memory before proposing architectural changes
- **Rationale:** Prevents violating frozen file rules (ADR-001) or DI patterns (ADR-003)
- **Enforcement:** Story execution templates include memory query steps

**Example:**
```markdown
## Story Execution Checklist
- [ ] Query memory: "frozen files and file size limits"
- [ ] Query memory: "dependency injection patterns and service wiring"
- [ ] Query memory: "IPC handler design constraints"
- [ ] Propose extraction plan (do not modify frozen files)
```

**Rule 2: Index Story Artifacts**
- **Requirement:** All story completions MUST index execution logs to memory
- **Rationale:** Future agents learn from past refactoring decisions
- **Enforcement:** Story completion templates include `ingest_document()` call

**Example:**
```javascript
// After completing ADR-009 Repository Layer extraction
await mcp.invoke('ingest_document', {
  file_path: "stories/3.2.repository-extraction-log.md",
  metadata: {
    document_type: "Story",
    tags: ["extraction", "repository", "database"],
    epic: "epic-3-refactoring",
    status: "completed"
  }
});
```

**Rule 3: Semantic Query Over File Search**
- **Requirement:** Agents use semantic queries first, file search second
- **Rationale:** Memory provides context-aware results (e.g., "What constraints apply to IPC handlers?" → ADR-002)
- **Enforcement:** Agent prompts prioritize `query_memory()` over `grep` for documentation

**Rule 4: Local Obsidian Edits Only**
- **Requirement:** Developers edit documentation in Obsidian, not directly in ./docs
- **Rationale:** Preserves Obsidian features (backlinks, graph) and prevents symlink corruption
- **Enforcement:** Documentation guidelines + CI warning if ./docs is a regular directory

**Rule 5: Cross-Project Memory Reuse**
- **Requirement:** Qdrant collections may be shared across related projects
- **Rationale:** Common architectural patterns (DI, Repository, Strangler Fig) apply portfolio-wide
- **Enforcement:** Collection naming: `{project}-{category}` (e.g., `gen-image-factory-architecture`)

### 4. Developer Workflow

#### Initial Setup (One-Time)
```bash
# 1. Create Obsidian vault (if not exists)
mkdir -p ~/Documents/Obsidian/BMad-Projects/gen-image-factory

# 2. Move existing ./docs to Obsidian
mv ./docs/* ~/Documents/Obsidian/BMad-Projects/gen-image-factory/

# 3. Create symlink
ln -s ~/Documents/Obsidian/BMad-Projects/gen-image-factory ./docs

# 4. Configure MCP in Cursor
# Edit .cursor/mcp_config.json (see Component 4)

# 5. Ingest existing documentation
cd /path/to/bmad-qdrant-knowledge-management
npm run ingest:gen-image-factory
```

#### Daily Workflow
```bash
# 1. Edit docs in Obsidian (use graph view, backlinks, etc.)
# 2. Changes automatically visible in IDE via symlink
# 3. Git tracks changes (commit as normal)
# 4. Agents query memory via MCP (automatic during story execution)

# Optional: Manual memory ingestion after major doc updates
npm run ingest:gen-image-factory
```

#### Agent Story Execution
```
1. Story Start:
   → Agent queries memory for relevant ADRs
   → Loads 3-5 documents (not all 40+)
   → Validates constraints (frozen files, DI patterns)

2. During Development:
   → Agent queries specific constraints ("IPC handler limits?")
   → Memory returns ADR-002 with context

3. Story Completion:
   → Agent indexes execution log to memory
   → Future agents learn from this refactoring
```

### 5. Migration Strategy

**Phase 1: Foundation (Week 1)**
1. Create Obsidian vault structure
2. Move `./docs` to Obsidian, create symlink
3. Set up Qdrant instance (Cloud or self-hosted)
4. Configure MCP in Cursor (`.cursor/mcp_config.json`)

**Phase 2: Ingestion (Week 1)**
1. Ingest existing ADRs (12 documents)
2. Ingest coding standards and tech stack docs
3. Ingest PRD shards (if applicable)
4. Test semantic queries: "Which files are frozen?" → ADR-001

**Phase 3: Agent Integration (Week 2)**
1. Update story execution templates to include memory queries
2. Add memory query examples to agent prompts
3. Test agent memory retrieval in dry-run story

**Phase 4: Workflow Adoption (Week 2)**
1. Document Obsidian setup in `README.md`
2. Add story artifact indexing workflow
3. Train agents to index completion logs

**Phase 5: Cross-Project Expansion (Future)**
1. Replicate pattern for other BMad projects
2. Create shared collections for common patterns (DI, Repository, Testing)
3. Enable cross-project backlinks in Obsidian

## Consequences

### Positive

1. **Developer Experience:**
   - **Obsidian Features:** Graph view, backlinks, powerful search, dataview queries
   - **IDE Integration:** Full Cursor/VSCode support via symlink
   - **No Duplication:** Single source of truth (Obsidian vault)

2. **Agent Context Efficiency:**
   - **70-80% token reduction:** Agents load 3-5 ADRs instead of 40+ docs
   - **Semantic Queries:** "What constraints apply to IPC?" → ADR-002 (automatic)
   - **Faster Responses:** Less document parsing overhead

3. **Knowledge Continuity:**
   - **Story Artifacts Indexed:** Past refactorings inform future decisions
   - **Portfolio-Wide Memory:** Common patterns (DI, Repository) shared across projects
   - **Cross-Project Backlinks:** Obsidian graph spans multiple codebases

4. **Separation of Concerns:**
   - **Memory Management:** Separate repo (`bmad-qdrant-knowledge-management`)
   - **Application Code:** This repo remains focused on application logic
   - **Clear Boundaries:** Ingestion pipeline isolated from app codebase

5. **Flexibility:**
   - **Qdrant Hosting:** Cloud (persistent) or Docker (privacy)
   - **Embedding Models:** OpenAI (fast) or local (private)
   - **MCP Transport:** stdio (local) or HTTP (remote)

### Negative

1. **Setup Complexity:**
   - **Initial Overhead:** Obsidian vault setup, symlink creation, MCP configuration (~30 minutes)
   - **Qdrant Management:** Separate repository adds infrastructure complexity
   - **Developer Onboarding:** Team members must set up local symlinks

2. **Symlink Limitations:**
   - **Windows Support:** Symlinks require administrator privileges or Developer Mode
   - **Git Portability:** Symlink targets must be configured per developer
   - **Sync Issues:** If Obsidian vault path changes, symlink breaks

3. **Dependency on External Services:**
   - **Qdrant Availability:** Agents require Qdrant instance to be running
   - **MCP Dependency:** Cursor must support MCP (currently supported)
   - **Embedding API:** Ingestion requires OpenAI API (or local alternative)

4. **Ingestion Workflow:**
   - **Manual Trigger:** Developers must run `npm run ingest` after major doc updates
   - **Embedding Costs:** OpenAI API usage (~$0.02 per full ingestion of 40 docs)
   - **Ingestion Time:** ~5-10 minutes for full re-ingestion

5. **Two-Repository Maintenance:**
   - **Version Alignment:** Must keep `bmad-qdrant-knowledge-management` repo updated
   - **Configuration Drift:** MCP config in `.cursor/mcp_config.json` must match Qdrant instance
   - **Documentation Duplication:** Setup docs exist in both repos

### Migration Risks & Mitigation

**Risk 1: Symlink Breaks During Git Operations**
- **Mitigation:** Document symlink creation in `README.md`. Add CI check to verify symlink exists.

**Risk 2: Qdrant Instance Unavailable**
- **Mitigation:** Agents gracefully degrade to file search if MCP query fails. Memory is enhancement, not requirement.

**Risk 3: Obsidian Vault Path Changes**
- **Mitigation:** Use environment variable for vault path (`.env.local`). Script to re-create symlink.

**Risk 4: Embedding API Rate Limits**
- **Mitigation:** Implement incremental ingestion (only changed files). Cache embeddings locally.

### Rollback Plan

If the Obsidian-Qdrant bridge proves impractical:
1. **Remove symlink:** `rm ./docs`
2. **Restore directory:** `mv ~/Documents/Obsidian/BMad-Projects/gen-image-factory ./docs`
3. **Remove MCP config:** Delete `.cursor/mcp_config.json` entry
4. **Remove Qdrant dependency:** Stop using `bmad-qdrant-knowledge-management` repo
5. **Fallback:** Agents return to manual document attachment (status quo)

**No Data Loss:** Obsidian vault and Git history preserve all documentation.

## Related ADRs
- ADR-001: File Size Guardrail (memory helps agents remember frozen files)
- ADR-002: Vertical Slice Architecture for IPC (memory stores IPC handler constraints)
- ADR-003: Dependency Injection over Global State (memory stores DI patterns)
- ADR-006: Solo-Developer Testing & Rollout Strategy (memory tracks feature flags)
- ADR-009: Persistence Repository Layer (memory stores extraction patterns)

## References
- **BMAD Qdrant Integration:** https://github.com/Hidden-History/bmad-qdrant-knowledge-management
  - `CONFIGURATION.md` - Qdrant instance setup
  - `BMAD_INTEGRATION_RULES.md` - Agent governance rules
  - `QUICKSTART.md` - Initial setup guide
- **Model Context Protocol (MCP):** https://modelcontextprotocol.info/
- **Qdrant Documentation:** https://qdrant.tech/documentation/
- **Obsidian Documentation:** https://help.obsidian.md/
- **Symlinks in Git:** https://git-scm.com/docs/git-symbolic-ref
- **RAG (Retrieval-Augmented Generation):** https://arxiv.org/abs/2005.11401

## Appendix: MCP Server Implementation

**File:** `bmad-qdrant-knowledge-management/mcp-server.js`

**Minimal Implementation:**
```javascript
import { MCPServer } from '@modelcontextprotocol/sdk';
import { QdrantClient } from '@qdrant/js-client-rest';

const qdrant = new QdrantClient({
  url: process.env.QDRANT_URL,
  apiKey: process.env.QDRANT_API_KEY
});

const server = new MCPServer({
  name: 'bmad-qdrant',
  version: '1.0.0'
});

server.tool('query_memory', async ({ query, collection, limit = 5 }) => {
  const results = await qdrant.search(collection, {
    vector: await generateEmbedding(query),
    limit,
    with_payload: true
  });
  
  return results.map(r => ({
    file_path: r.payload.file_path,
    score: r.score,
    excerpt: r.payload.excerpt,
    metadata: r.payload.metadata
  }));
});

server.tool('ingest_document', async ({ file_path, metadata }) => {
  // Implementation in bmad-qdrant-knowledge-management repo
});

server.listen({ transport: 'stdio' });
```

## Appendix: Governance Checklist for Agents

**Pre-Refactoring Queries:**
```
[ ] Query: "frozen files and file size limits" → Load ADR-001
[ ] Query: "dependency injection patterns and service wiring" → Load ADR-003
[ ] Query: "IPC handler design constraints" → Load ADR-002
[ ] Query: "repository layer extraction patterns" → Load ADR-009
[ ] Query: "testing and rollout strategy" → Load ADR-006
```

**Post-Story Indexing:**
```javascript
await mcp.invoke('ingest_document', {
  file_path: `stories/${epicNumber}.${storyNumber}-${storySlug}.md`,
  metadata: {
    document_type: "Story",
    tags: extractedTags,
    epic: epicNumber,
    status: "completed",
    last_modified: new Date().toISOString()
  }
});
```
