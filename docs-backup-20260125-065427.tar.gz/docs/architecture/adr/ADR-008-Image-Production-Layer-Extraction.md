# ADR-008: Image Production Layer Extraction

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** extraction, image-processing, service-boundaries, pipeline-architecture

## Context

`producePictureModule.js` (799 lines) is a monolithic file that combines three distinct responsibilities:
1. **Image Generation:** Runware API integration and image URL extraction (lines ~223-519)
2. **Background Removal:** remove.bg API integration and alpha trimming (lines ~21-87, ~584-692)
3. **Image Processing:** Sharp-based buffer manipulation (sharpening, saturation, format conversion) (lines ~521-798)

**Problems:**
- **Violates SRP:** Single file handles API calls, external service integration, and image manipulation
- **Hard to Test:** Cannot test image processing without API keys or external services
- **Tight Coupling:** Processing logic is intertwined with generation logic
- **Future Pipeline Epic:** Current structure prevents dynamic service ordering for future pipeline architecture

**Current Usage:**
- `producePictureModule.js` is the **active backend** for the Electron app
- Called directly from `JobRunner.generateImages()` (line 2244)
- `processImage()` called from `JobRunner` (line 1323) and `RetryExecutor` (line 782)
- Critical production code that must remain functional during extraction

## Decision

We extract `producePictureModule.js` into **three domain-focused services** following the Strangler Fig pattern (ADR-001) and safe rollout strategy (ADR-006).

### 1. Service Boundaries

#### ImageGeneratorService
**Scope:** Runware API integration and image URL extraction  
**Lines:** ~223-519 (main generation logic)  
**Responsibility:**
- Orchestrating external generation requests to Runware API
- Building request payloads (model, dimensions, LoRA, advanced params)
- Extracting image URLs from Runware responses
- Top-up logic for variations
- Helper functions: `sanitizePromptForRunware()`, `extractRunwareImageUrls()`, `getRunwareDimensionsForGeneration()`

**Interface:**
```javascript
class ImageGeneratorService {
  constructor(runwareApiKey) {
    this.apiKey = runwareApiKey;
  }
  
  /**
   * Generate images via Runware API
   * @param {Object} config - Generation configuration
   * @param {AbortSignal} abortSignal - Cancellation signal
   * @returns {Promise<Array<string>>} - Array of image URLs
   */
  async generateImages(config, abortSignal) {
    // Returns: ['https://...', 'https://...']
  }
}
```

#### ImageRemoverService
**Scope:** Background removal and alpha trimming  
**Lines:** ~21-87 (removeBg function), ~584-692 (processImage remove.bg logic)  
**Responsibility:**
- remove.bg API integration
- Retry logic for remove.bg failures
- Alpha channel trimming (transparent background removal)
- Error handling and fallback strategies

**Reasoning:** In Phase 1, we group BG removal and its associated alpha-trimming as a single functional domain since they are tightly coupled (trim requires remove.bg to be enabled).

**Interface:**
```javascript
class ImageRemoverService {
  constructor(removeBgApiKey) {
    this.apiKey = removeBgApiKey;
  }
  
  /**
   * Remove background from image
   * @param {Buffer|string} input - Image buffer or file path
   * @param {Object} options - { size, timeout, signal }
   * @returns {Promise<Buffer>} - Image buffer with background removed
   */
  async removeBackground(input, options) {
    // Returns: Buffer
  }
  
  /**
   * Trim transparent background
   * @param {Buffer} imageBuffer - Image buffer with alpha channel
   * @returns {Promise<Buffer>} - Trimmed image buffer
   */
  async trimTransparentBackground(imageBuffer) {
    // Returns: Buffer
  }
}
```

#### ImageProcessorService
**Scope:** Pure Sharp-based image manipulation  
**Lines:** ~694-798 (enhancement, conversion logic)  
**Responsibility:**
- Image enhancement (sharpening, saturation)
- Format conversion (PNG, JPG, WEBP)
- Quality settings
- Buffer manipulation using Sharp

**Constraint:** This service must remain **independent** of BG removal logic to allow for optional processing in the future pipeline architecture.

**Interface:**
```javascript
class ImageProcessorService {
  /**
   * Apply image enhancement effects
   * @param {Buffer} imageBuffer - Input image buffer
   * @param {Object} options - { sharpening, saturation }
   * @returns {Promise<Buffer>} - Enhanced image buffer
   */
  async enhanceImage(imageBuffer, options) {
    // Returns: Buffer
  }
  
  /**
   * Convert image format
   * @param {Buffer} imageBuffer - Input image buffer
   * @param {Object} options - { format, quality, backgroundColor }
   * @returns {Promise<Buffer>} - Converted image buffer
   */
  async convertFormat(imageBuffer, options) {
    // Returns: Buffer
  }
}
```

### 2. Standard Interface Contract

**Rule:** All extracted services must accept an image **Buffer** (or file path) and return a modified **Buffer**.

**Rationale:**
- Enables future "Pipeline Epic" where services can be ordered dynamically
- Services remain stateless and composable
- No internal logic changes required when reordering pipeline steps
- Testable with dummy buffers (no API keys required for ImageProcessorService)

**Interface Pattern:**
```javascript
// All services follow this pattern:
async process(input: Buffer | string, options: Object): Promise<Buffer>
```

### 3. Integration & Rollout (ADR-006)

**Feature Flags:**
- `FEATURE_MODULAR_GENERATOR` - Toggle ImageGeneratorService
- `FEATURE_MODULAR_REMOVER` - Toggle ImageRemoverService  
- `FEATURE_MODULAR_PROCESSOR` - Toggle ImageProcessorService

**Bridge Pattern:**
```javascript
// In producePictureModule.js (Frozen Monolith)
async function producePictureModule(settings, imgNameBase, customMetadataPrompt, config) {
  if (process.env.FEATURE_MODULAR_GENERATOR === 'true') {
    const generator = new ImageGeneratorService(process.env.RUNWARE_API_KEY);
    const imageUrls = await generator.generateImages(config, config.abortSignal);
    // Continue with new services...
  } else {
    // Legacy implementation (lines 223-519)
  }
}

async function processImage(inputImagePath, imgName, config) {
  let imageBuffer = await fs.readFile(inputImagePath);
  
  // Background removal
  if (config.removeBg) {
    if (process.env.FEATURE_MODULAR_REMOVER === 'true') {
      const remover = new ImageRemoverService(process.env.REMOVE_BG_API_KEY);
      imageBuffer = await remover.removeBackground(imageBuffer, config);
      if (config.trimTransparentBackground) {
        imageBuffer = await remover.trimTransparentBackground(imageBuffer);
      }
    } else {
      // Legacy implementation (lines 584-692)
    }
  }
  
  // Image processing
  if (process.env.FEATURE_MODULAR_PROCESSOR === 'true') {
    const processor = new ImageProcessorService();
    if (config.imageEnhancement) {
      imageBuffer = await processor.enhanceImage(imageBuffer, {
        sharpening: config.sharpening,
        saturation: config.saturation
      });
    }
    if (config.imageConvert) {
      imageBuffer = await processor.convertFormat(imageBuffer, {
        format: config.convertToJpg ? 'jpg' : 'png',
        quality: config.jpgQuality || config.pngQuality,
        backgroundColor: config.jpgBackground
      });
    }
  } else {
    // Legacy implementation (lines 694-798)
  }
  
  return imageBuffer;
}
```

### 4. Testing Requirements

**Mandatory Vitest Unit Tests:**
- **ImageGeneratorService:** Mock Runware API calls, test URL extraction, test top-up logic
- **ImageRemoverService:** Mock remove.bg API calls, test retry logic, test alpha trimming
- **ImageProcessorService:** **Must be testable with dummy buffers** - no API keys required

**Test Structure:**
```javascript
// src/services/ImageProcessorService.test.js
import { describe, it, expect } from 'vitest';
import { ImageProcessorService } from './ImageProcessorService';
import sharp from 'sharp';

describe('ImageProcessorService', () => {
  it('should enhance image with sharpening', async () => {
    const service = new ImageProcessorService();
    const dummyBuffer = await sharp({
      create: { width: 100, height: 100, channels: 3, background: 'red' }
    }).png().toBuffer();
    
    const result = await service.enhanceImage(dummyBuffer, { sharpening: 5 });
    expect(Buffer.isBuffer(result)).toBe(true);
  });
});
```

**Bridge Integration Tests:**
- Test feature flag toggling (both paths)
- Test fallback to legacy when new service fails
- Verify both code paths produce equivalent results

## Consequences

### Positive
- **Separation of Concerns:** Each service has a single, clear responsibility
- **Testability:** ImageProcessorService can be tested without external dependencies
- **Pipeline Ready:** Buffer-based interfaces enable future dynamic pipeline ordering
- **Independent Deployment:** Services can be extracted and tested independently
- **Better Error Handling:** Isolated services enable targeted error handling

### Negative
- **Initial Refactoring:** Requires careful extraction to maintain functionality
- **More Files:** Three services instead of one module
- **Bridge Complexity:** Feature flags add routing logic during transition

### Migration Path

1. **Phase 1 (Freeze):** Add `producePictureModule.js` to Master Frozen List (ADR-001)
2. **Phase 2 (Extract):** Create three services with comprehensive Vitest tests
3. **Phase 3 (Bridge):** Implement feature flags and bridge routing in frozen module
4. **Phase 4 (Ship):** Deploy to `main` with flags disabled (legacy active)
5. **Phase 5 (Verify):** Enable flags locally, run Playwright E2E tests
6. **Phase 6 (Finalize):** After 2-3 stable releases, remove legacy code and flags

## Future Pipeline Epic

This extraction prepares for a future "Pipeline Epic" where image processing steps can be:
- **Dynamically Ordered:** Services can be reordered without code changes
- **Conditionally Executed:** Steps can be skipped based on configuration
- **Composably Tested:** Each step can be tested in isolation

**Example Future Pipeline:**
```javascript
const pipeline = [
  new ImageGeneratorService(),
  new ImageRemoverService(), // Optional
  new ImageProcessorService(), // Optional
  new QualityCheckService(), // Future
  new MetadataService() // Future
];

for (const step of pipeline) {
  if (shouldExecute(step, config)) {
    imageBuffer = await step.process(imageBuffer, config);
  }
}
```

## Related ADRs
- ADR-001: File Size Guardrail (frozen monoliths)
- ADR-003: Dependency Injection over Global State
- ADR-006: Solo-Developer Testing & Rollout Strategy (feature flags, bridge pattern)

## References
- [Strangler Fig Pattern](https://martinfowler.com/bliki/StranglerFigApplication.html)
- Single Responsibility Principle (SOLID)
- [Sharp Documentation](https://sharp.pixelplumbing.com/)
