# ADR-009: Persistence Repository Layer

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** persistence, repository-pattern, database, extraction

## Context

The database models `JobExecution.js` (1,100 lines) and `GeneratedImage.js` (1,000 lines) violate the Single Responsibility Principle by combining:
1. **Schema Definitions:** Sequelize/SQLite table structure
2. **Business Logic:** Complex query methods, data transformations, statistics calculations
3. **Database Initialization:** Path resolution, connection management
4. **Instance Methods:** Data manipulation and validation logic

**Problems:**
- **Schema Pollution:** Business logic mixed with data structure definitions
- **Hard to Test:** Cannot test queries without database setup
- **Tight Coupling:** Services depend on model classes instead of interfaces
- **Violates SRP:** Models handle persistence, business rules, and data transformation
- **Exceeds Size Limit:** Both models exceed 400-line limit (ADR-001)

**Current State:**
- Models contain complex SQL queries (JOINs, aggregations, statistics)
- Business logic embedded in instance methods
- Data transformation logic mixed with persistence
- Models are directly imported and used throughout the codebase

## Decision

We extract all business logic from Sequelize models into a **Repository Layer** following the Repository Pattern.

### 1. Target Architecture

**Models (Schema Only):**
- **Target:** < 200 lines per model
- **Responsibility:** Only Sequelize/SQLite schema definitions
- **Contains:**
  - Table structure (columns, types, constraints)
  - Foreign key relationships
  - Index definitions
  - Basic validation rules (NOT NULL, UNIQUE, etc.)

**Repository Layer (Business Logic):**
- **Location:** `src/repositories/`
- **Responsibility:** All query logic, data transformations, business rules
- **Structure:**
  - `JobRepository.js` - JobExecution CRUD and queries
  - `ImageRepository.js` - GeneratedImage CRUD and queries
  - `JobConfigurationRepository.js` - JobConfiguration CRUD and queries

### 2. Extraction Boundaries

#### JobRepository
**Extracted from:** `JobExecution.js` (1,100 lines)

**Methods to Extract:**
- `getJobHistory(limit)` - Complex JOIN query with aggregations
- `getJobStatistics()` - Statistics calculations
- `getJobExecution(id)` - Data transformation and parsing
- `saveJobExecution(data)` - Business logic for saving
- `updateJobExecution(id, data)` - Update logic with validation
- `deleteJobExecution(id)` - Deletion with cascade handling
- `getJobExecutions(filters)` - Filtered queries

**Model Retains:**
- Schema definition (CREATE TABLE)
- Basic init() and close() methods
- Database path resolution

**Target:** Model reduced to ~150 lines (schema only)

#### ImageRepository
**Extracted from:** `GeneratedImage.js` (1,000 lines)

**Methods to Extract:**
- `getImageMetadata(executionId)` - JOIN queries with parsing
- `getImageStatistics()` - Aggregation queries
- `updateMetadataById(id, metadata)` - JSON merge logic
- `getImagesByQcStatus(status)` - Filtered queries
- `bulkUpdateQcStatus(mapping)` - Batch operations
- `deleteImagesByExecution(executionId)` - Cascade deletion

**Model Retains:**
- Schema definition (CREATE TABLE)
- Basic init() and close() methods
- Database path resolution

**Target:** Model reduced to ~150 lines (schema only)

### 3. Repository Interface Pattern

**Standard Interface:**
```javascript
class JobRepository {
  constructor(database) {
    this.db = database; // Injected database connection
  }
  
  // CRUD Operations
  async create(data) { }
  async findById(id) { }
  async update(id, data) { }
  async delete(id) { }
  
  // Business Queries
  async getHistory(limit) { }
  async getStatistics() { }
  async findByFilters(filters) { }
}
```

**Dependency Injection:**
- Repositories accept database connection in constructor (ADR-003)
- Models provide database connection via `init()` method
- Services depend on Repositories, not Models directly

### 4. Migration Strategy

**Phase 1: Create Repository Layer**
1. Create `src/repositories/JobRepository.js`
2. Create `src/repositories/ImageRepository.js`
3. Move query methods from models to repositories
4. Add comprehensive Vitest unit tests (≥70% coverage)

**Phase 2: Bridge Pattern (ADR-006)**
1. Add feature flag: `FEATURE_MODULAR_REPOSITORY`
2. Models delegate to repositories when flag enabled
3. Legacy methods remain in models as fallback

**Phase 3: Update Services**
1. Update `JobRunner` to use `JobRepository` instead of `JobExecution` model
2. Update `BackendAdapter` to use repositories
3. Update all direct model usages

**Phase 4: Finalize**
1. Remove business logic from models
2. Models become thin schema wrappers (< 200 lines)
3. Remove feature flag after 2-3 stable releases

### 5. Testing Requirements

**Repository Tests:**
- **Unit Tests (Vitest):** Mock database, test query logic
- **Integration Tests:** Use isolated test databases
- **Coverage:** ≥70% statement and branch coverage

**Model Tests:**
- **Schema Tests:** Verify table structure
- **Migration Tests:** Verify schema changes
- **No Business Logic Tests:** All moved to repositories

## Consequences

### Positive
- **Separation of Concerns:** Schema separate from business logic
- **Testability:** Repositories can be tested with mocked databases
- **Flexibility:** Can swap database implementations without changing business logic
- **Maintainability:** Query logic centralized in repositories
- **Compliance:** Models meet 400-line limit (target: < 200 lines)

### Negative
- **Initial Refactoring:** Requires careful extraction to maintain functionality
- **More Files:** Repository layer adds new files
- **Migration Overhead:** Must update all model usages

### Migration Example

**Before (Model with Business Logic):**
```javascript
// JobExecution.js (1,100 lines)
class JobExecution {
  async getJobHistory(limit = 50) {
    // 50 lines of complex SQL with JOINs
    const sql = `SELECT je.*, jc.name, ...`;
    // 30 lines of data transformation
    return transformedData;
  }
}
```

**After (Model - Schema Only):**
```javascript
// JobExecution.js (~150 lines)
class JobExecution {
  async init() {
    // Schema definition only
    const sql = `CREATE TABLE IF NOT EXISTS job_executions (...)`;
    // No business logic
  }
}
```

**After (Repository - Business Logic):**
```javascript
// src/repositories/JobRepository.js
class JobRepository {
  constructor(jobExecutionModel) {
    this.model = jobExecutionModel;
  }
  
  async getJobHistory(limit = 50) {
    // Complex query logic
    const sql = `SELECT je.*, jc.name, ...`;
    // Data transformation
    return transformedData;
  }
}
```

## Related ADRs
- ADR-001: File Size Guardrail (400-line limit)
- ADR-003: Dependency Injection over Global State
- ADR-006: Solo-Developer Testing & Rollout Strategy (feature flags, bridge pattern)

## References
- [Repository Pattern](https://martinfowler.com/eaaCatalog/repository.html)
- [Domain-Driven Design](https://martinfowler.com/bliki/DomainDrivenDesign.html)
- Single Responsibility Principle (SOLID)
