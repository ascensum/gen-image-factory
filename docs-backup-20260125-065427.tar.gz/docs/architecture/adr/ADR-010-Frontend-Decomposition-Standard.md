# ADR-010: Frontend Decomposition Standard

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** frontend, react, component-architecture, decomposition

## Context

The frontend contains monolithic React components that violate the Single Responsibility Principle:
- `DashboardPanel.tsx` (1,600 lines)
- `SettingsPanel.tsx` (1,400 lines)
- `FailedImagesReviewPanel.tsx` (1,200 lines)
- `JobManagementPanel.tsx` (1,100 lines)

**Problems:**
- **Component Bloat:** Single components handle multiple UI concerns (layout, state, API calls, business logic)
- **Hard to Test:** Cannot test individual features without rendering entire panel
- **Poor Reusability:** Logic is tightly coupled to specific panels
- **Maintenance Burden:** Changes require navigating 1,000+ line files
- **Violates Size Limit:** All panels exceed 400-line limit (ADR-001)

**Current State:**
- Panels combine container logic, presentation, state management, and API integration
- Business logic embedded in component methods
- No clear separation between View (container) and Component (presentation) layers

## Decision

We decompose monolithic panels into **Atomic Components** and **View Containers** following a clear separation of concerns.

### 1. Target Architecture

**View Layer (Containers):**
- **Location:** `src/renderer/components/[Feature]/views/`
- **Responsibility:** State management, API calls, orchestration
- **Size Limit:** < 400 lines (ADR-001)
- **Pattern:** Container components that compose atomic components

**Component Layer (Presentation):**
- **Location:** `src/renderer/components/[Feature]/components/`
- **Responsibility:** Pure presentation, user interactions
- **Size Limit:** < 400 lines (ADR-001)
- **Pattern:** Atomic, reusable components with props interface

**Hook Layer (Logic Extraction):**
- **Location:** `src/renderer/components/[Feature]/hooks/`
- **Responsibility:** Reusable state logic, API integration
- **Size Limit:** < 400 lines (ADR-001)
- **Pattern:** Custom hooks for shared logic

### 2. Decomposition Strategy

#### DashboardPanel.tsx (1,600 lines → Multiple Files)

**Extract to View:**
- `DashboardView.tsx` (< 400 lines) - Main container, orchestrates sub-views

**Extract to Components:**
- `JobControls.tsx` - Job start/stop controls (already exists, verify < 400 lines)
- `LogViewer.tsx` - Log display component (already exists, verify < 400 lines)
- `JobHistory.tsx` - History list component (already exists, verify < 400 lines)
- `ImageGallery.tsx` - Image grid component (already exists, verify < 400 lines)
- `HeaderMenu.tsx` - Navigation menu (extract from DashboardPanel)
- `StatisticsCard.tsx` - Statistics display (extract if exists)

**Extract to Hooks:**
- `useJobHistory.ts` - Job history fetching and state
- `useJobStatus.ts` - Job status polling and updates
- `useImageGallery.ts` - Image gallery state and operations
- `useExportOperations.ts` - Export functionality

**Target Structure:**
```
src/renderer/components/Dashboard/
├── views/
│   └── DashboardView.tsx (< 400 lines)
├── components/
│   ├── JobControls.tsx
│   ├── LogViewer.tsx
│   ├── JobHistory.tsx
│   ├── ImageGallery.tsx
│   ├── HeaderMenu.tsx
│   └── StatisticsCard.tsx
└── hooks/
    ├── useJobHistory.ts
    ├── useJobStatus.ts
    ├── useImageGallery.ts
    └── useExportOperations.ts
```

#### SettingsPanel.tsx (1,400 lines → Multiple Files)

**Extract to View:**
- `SettingsView.tsx` (< 400 lines) - Main container, tab navigation

**Extract to Components:**
- `ApiKeysSection.tsx` - Already exists, verify < 400 lines
- `FilePathsSection.tsx` - Already exists, verify < 400 lines
- `ParametersSection.tsx` - Already exists, verify < 400 lines
- `ProcessingSection.tsx` - Already exists, verify < 400 lines
- `AISection.tsx` - Already exists, verify < 400 lines
- `AdvancedSection.tsx` - Already exists, verify < 400 lines

**Extract to Hooks:**
- `useSettings.ts` - Settings state and persistence
- `useApiKeys.ts` - API key management
- `useFilePaths.ts` - File path selection and validation

**Target Structure:**
```
src/renderer/components/Settings/
├── views/
│   └── SettingsView.tsx (< 400 lines)
├── components/
│   ├── ApiKeysSection.tsx
│   ├── FilePathsSection.tsx
│   ├── ParametersSection.tsx
│   ├── ProcessingSection.tsx
│   ├── AISection.tsx
│   └── AdvancedSection.tsx
└── hooks/
    ├── useSettings.ts
    ├── useApiKeys.ts
    └── useFilePaths.ts
```

#### FailedImagesReviewPanel.tsx (1,200 lines → Multiple Files)

**Extract to View:**
- `FailedImagesReviewView.tsx` (< 400 lines) - Main container

**Extract to Components:**
- `FailedImageList.tsx` - List of failed images
- `FailedImageCard.tsx` - Individual failed image card
- `ReviewActions.tsx` - Approve/reject actions
- `BulkActions.tsx` - Bulk operation controls

**Extract to Hooks:**
- `useFailedImages.ts` - Failed images fetching and filtering
- `useImageReview.ts` - Review operations (approve/reject)

**Target Structure:**
```
src/renderer/components/Dashboard/
├── views/
│   └── FailedImagesReviewView.tsx (< 400 lines)
├── components/
│   ├── FailedImageList.tsx
│   ├── FailedImageCard.tsx
│   ├── ReviewActions.tsx
│   └── BulkActions.tsx
└── hooks/
    ├── useFailedImages.ts
    └── useImageReview.ts
```

#### JobManagementPanel.tsx (1,100 lines → Multiple Files)

**Extract to View:**
- `JobManagementView.tsx` (< 400 lines) - Main container

**Extract to Components:**
- `JobList.tsx` - List of jobs
- `JobCard.tsx` - Individual job card
- `JobFilters.tsx` - Filter controls
- `JobActions.tsx` - Job operations (rerun, delete, export)

**Extract to Hooks:**
- `useJobList.ts` - Job list fetching and filtering
- `useJobOperations.ts` - Job operations (rerun, delete, export)

**Target Structure:**
```
src/renderer/components/Jobs/
├── views/
│   └── JobManagementView.tsx (< 400 lines)
├── components/
│   ├── JobList.tsx
│   ├── JobCard.tsx
│   ├── JobFilters.tsx
│   └── JobActions.tsx
└── hooks/
    ├── useJobList.ts
    └── useJobOperations.ts
```

### 3. Component Size Standards

**View Containers:**
- **Limit:** < 400 lines (ADR-001)
- **Content:** State management, API calls, component composition
- **No Business Logic:** Delegate to hooks or services

**Atomic Components:**
- **Limit:** < 400 lines (ADR-001)
- **Content:** Presentation, user interactions, prop handling
- **No API Calls:** Receive data via props

**Custom Hooks:**
- **Limit:** < 400 lines (ADR-001)
- **Content:** Reusable state logic, API integration
- **Single Responsibility:** One hook = one concern

### 4. Migration Strategy

**Phase 1: Extract Hooks**
1. Identify reusable logic in panels
2. Extract to custom hooks
3. Add Vitest tests for hooks

**Phase 2: Extract Components**
1. Identify presentation components
2. Extract to atomic components
3. Add React Testing Library tests

**Phase 3: Create View Containers**
1. Refactor panels to thin view containers
2. Compose atomic components
3. Use extracted hooks for logic

**Phase 4: Verify Size Limits**
1. Ensure all files < 400 lines
2. Run full test suite
3. Update documentation

### 5. Testing Requirements

**View Tests:**
- **Integration Tests:** Test component composition
- **E2E Tests:** Test full user workflows

**Component Tests:**
- **Unit Tests (React Testing Library):** Test presentation and interactions
- **Coverage:** ≥70% statement and branch coverage

**Hook Tests:**
- **Unit Tests (Vitest):** Test state logic and API integration
- **Mock Dependencies:** Mock `window.api` calls

## Consequences

### Positive
- **Maintainability:** Smaller, focused files are easier to understand
- **Reusability:** Atomic components can be reused across views
- **Testability:** Components and hooks can be tested in isolation
- **Compliance:** All files meet 400-line limit (ADR-001)
- **Better Organization:** Clear separation of concerns

### Negative
- **Initial Refactoring:** Requires careful extraction to maintain functionality
- **More Files:** Decomposition creates more files (but better organized)
- **Migration Overhead:** Must update imports and component structure

### Migration Example

**Before (Monolithic Panel):**
```tsx
// DashboardPanel.tsx (1,600 lines)
const DashboardPanel = () => {
  const [jobs, setJobs] = useState([]);
  const [status, setStatus] = useState('idle');
  
  useEffect(() => {
    // 100 lines of API calls
  }, []);
  
  const handleStart = async () => {
    // 50 lines of logic
  };
  
  return (
    <div>
      {/* 1,400 lines of JSX */}
    </div>
  );
};
```

**After (Decomposed):**
```tsx
// views/DashboardView.tsx (< 400 lines)
import { useJobHistory } from '../hooks/useJobHistory';
import { useJobStatus } from '../hooks/useJobStatus';
import JobControls from '../components/JobControls';
import JobHistory from '../components/JobHistory';

const DashboardView = () => {
  const { jobs, loading } = useJobHistory();
  const { status, startJob, stopJob } = useJobStatus();
  
  return (
    <div>
      <JobControls status={status} onStart={startJob} onStop={stopJob} />
      <JobHistory jobs={jobs} loading={loading} />
    </div>
  );
};

// hooks/useJobHistory.ts (< 400 lines)
export const useJobHistory = () => {
  const [jobs, setJobs] = useState([]);
  // Logic extracted here
  return { jobs, loading };
};

// components/JobControls.tsx (< 400 lines)
const JobControls = ({ status, onStart, onStop }) => {
  // Pure presentation
};
```

## Related ADRs
- ADR-001: File Size Guardrail (400-line limit)
- ADR-007: CSS Standards - Tailwind-First Development
- ADR-006: Solo-Developer Testing & Rollout Strategy

## References
- [Atomic Design](https://bradfrost.com/blog/post/atomic-web-design/)
- [Container/Presenter Pattern](https://medium.com/@dan_abramov/smart-and-dumb-components-7ca2f9a7c7d0)
- [React Hooks](https://react.dev/reference/react)
