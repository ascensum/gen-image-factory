# ADR-007: CSS Standards - Tailwind-First Development

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** frontend, styling, maintainability, tailwind

## Context

The codebase contains large CSS files that indicate style hoarding and poor separation of concerns:
- `src/renderer/components/Jobs/SingleJobView.css`: 1,300+ lines
- Component-specific CSS files are growing unbounded
- Mix of Tailwind utility classes and custom CSS creates inconsistency
- Large CSS files are difficult to maintain and refactor

**Problems:**
- **Style Hoarding:** Single component CSS files exceed 1,000 lines
- **Inconsistent Patterns:** Mix of Tailwind utilities and custom CSS
- **Poor Maintainability:** Large CSS files are hard to navigate and modify
- **Lost Benefits:** Not leveraging Tailwind's utility-first approach effectively

## Decision

We establish **Tailwind-First** development as the standard CSS approach:

1. **Primary Rule: Tailwind Utilities**
   - All styling must use Tailwind utility classes as the primary method
   - Inline Tailwind classes in `.tsx` files are preferred
   - Custom CSS should be the exception, not the rule

2. **CSS File Size Limit:**
   - Component CSS files must be **< 100 lines**
   - Files exceeding 100 lines must be refactored to Tailwind or split into CSS Modules
   - **Target:** Move 90% of styling to inline Tailwind classes

3. **CSS Modules for Complex Cases:**
   - Use CSS Modules (`.module.css`) only for:
     - Complex animations that cannot be expressed in Tailwind
     - Pseudo-selectors with complex logic (`:hover`, `:focus`, `:before`, `:after`)
     - Third-party component overrides that require specificity
   - CSS Modules must be co-located with their component
   - Example: `SingleJobView.tsx` → `SingleJobView.module.css` (if needed)

4. **Refactoring Strategy for Large CSS Files:**
   - **Step 1:** Audit existing CSS file for Tailwind-equivalent utilities
   - **Step 2:** Convert 90% of styles to inline Tailwind classes in `.tsx`
   - **Step 3:** Extract remaining complex styles to CSS Module (if needed)
   - **Step 4:** Delete original CSS file once migration is complete

5. **Database Model CSS Exception:**
   - Documentation-only CSS (e.g., `website/src/css/custom.css` for Docusaurus) is exempt
   - Focus enforcement on production application code only

## Consequences

### Positive
- **Consistency:** Uniform styling approach across the codebase
- **Maintainability:** Smaller, focused CSS files are easier to manage
- **Performance:** Tailwind's purging reduces CSS bundle size
- **Developer Experience:** Utility classes are discoverable and composable
- **Reduced Style Conflicts:** Utility classes have predictable specificity

### Negative
- **Initial Refactoring:** Large CSS files require migration effort
- **Learning Curve:** Team must be familiar with Tailwind utility classes
- **HTML Verbosity:** Inline Tailwind classes can make JSX more verbose (mitigated by component composition)

### Migration Path

1. **Phase 1 (Immediate):** Freeze large CSS files - no new styles may be added
2. **Phase 2 (Audit):** Identify Tailwind-equivalent utilities for existing styles
3. **Phase 3 (Refactor):** Convert styles to inline Tailwind classes in components
4. **Phase 4 (Extract):** Move complex animations/pseudo-selectors to CSS Modules
5. **Phase 5 (Cleanup):** Remove original CSS files once migration is complete

## Examples

### Bad Pattern (Large CSS File)
```css
/* SingleJobView.css - 1,300 lines */
.job-container {
  display: flex;
  flex-direction: column;
  padding: 1rem;
  /* ... 1,200 more lines ... */
}
```

### Good Pattern (Tailwind-First)
```tsx
// SingleJobView.tsx
<div className="flex flex-col p-4 bg-gray-100 rounded-lg">
  {/* Component content */}
</div>
```

### CSS Module for Complex Cases
```css
/* SingleJobView.module.css - < 100 lines */
.complexAnimation {
  animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
  from { transform: translateX(-100%); }
  to { transform: translateX(0); }
}
```

```tsx
// SingleJobView.tsx
import styles from './SingleJobView.module.css';

<div className={`flex flex-col p-4 ${styles.complexAnimation}`}>
  {/* Component content */}
</div>
```

## Enforcement

- **Pre-commit Hooks:** Flag CSS files > 100 lines
- **Code Review:** Reject PRs that add styles to frozen CSS files
- **Linting:** ESLint rules to prefer Tailwind utilities over custom CSS

## Related ADRs
- ADR-001: File Size Guardrail (400-line limit for source files)
- ADR-002: Vertical Slice Architecture for IPC
- ADR-003: Dependency Injection over Global State

## References
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [CSS Modules](https://github.com/css-modules/css-modules)
- [Utility-First CSS](https://tailwindcss.com/docs/utility-first)
