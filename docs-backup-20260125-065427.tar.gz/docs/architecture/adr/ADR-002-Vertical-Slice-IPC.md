# ADR-002: Vertical Slice Architecture for IPC

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** architecture, ipc, separation-of-concerns

## Context

`BackendAdapter.js` (3,407 lines) is a "God Class" that violates the Single Responsibility Principle by handling:
- IPC event routing (lines ~300-900)
- Database operations (lines ~1000-2000)
- Security/encryption (lines ~50-150)
- Excel/ZIP export (lines ~2200-2600)
- Service initialization and orchestration

The IPC handlers are particularly problematic:
- All IPC handlers are grouped in one massive file
- Handlers contain business logic (validation, transformation, error handling)
- Handlers are tightly coupled to BackendAdapter's internal state
- Testing IPC handlers requires mocking the entire BackendAdapter

This creates:
- **High Coupling:** IPC layer knows about database schemas, business rules, and infrastructure
- **Poor Testability:** Cannot test IPC handlers in isolation
- **Violation of SRP:** One class handles presentation (IPC), persistence (DB), and business logic

## Decision

We adopt a **Vertical Slice Architecture** for IPC handlers:

1. **Controller Pattern:**
   - IPC handlers are defined in dedicated Controller files per feature domain
   - `src/controllers/JobController.js` handles `job:*` events
   - `src/controllers/SettingsController.js` handles `settings:*` events
   - `src/controllers/ExportController.js` handles `export:*` events
   - `src/controllers/SecurityController.js` handles `security:*` events

2. **Handler Size Limit:**
   - Each IPC handler must be **< 5 lines**
   - Handlers are thin adapters that delegate to Services
   - **Bad Pattern:**
     ```javascript
     ipc.handle('job:start', async (event, args) => {
       // 50 lines of validation
       // 30 lines of transformation
       // 20 lines of error handling
       // Direct database calls
     })
     ```
   - **Good Pattern:**
     ```javascript
     ipc.handle('job:start', (event, args) => 
       jobService.start(args)
     )
     ```

3. **Controller Registration:**
   - `electron/main.js` loads and registers controllers dynamically
   - Controllers are self-contained modules that register their own handlers
   - Example:
     ```javascript
     // src/controllers/JobController.js
     export function registerJobHandlers(ipcMain, jobService) {
       ipcMain.handle('job:start', (e, args) => jobService.start(args))
       ipcMain.handle('job:stop', (e) => jobService.stop())
       // ... other handlers
     }
     ```

4. **Separation of Concerns:**
   - **Controllers:** Map IPC events to Service method calls (presentation layer)
   - **Services:** Contain business logic and orchestration (application layer)
   - **Repositories:** Handle persistence (infrastructure layer)

## Consequences

### Positive
- **Improved Testability:** Controllers can be tested with mocked Services
- **Clear Boundaries:** Presentation (IPC) is separated from business logic
- **Feature Cohesion:** Related IPC handlers are grouped by domain
- **Easier Refactoring:** Changes to IPC contract don't affect business logic
- **Better Organization:** New features add new controllers, not modify BackendAdapter

### Negative
- **More Files:** Codebase will have more controller files
- **Initial Migration:** Requires extracting handlers from BackendAdapter
- **Registration Overhead:** Need to manage controller registration in main.js

### Migration Path
1. **Phase 1:** Create `src/controllers/` directory structure
2. **Phase 2:** Extract one feature at a time (start with SettingsController)
3. **Phase 3:** Update `main.js` to register new controllers
4. **Phase 4:** Remove IPC handlers from BackendAdapter
5. **Phase 5:** BackendAdapter becomes a thin Service layer (see ADR-003)

## Example Structure

```
src/
├── controllers/
│   ├── JobController.js       # job:* events
│   ├── SettingsController.js  # settings:* events
│   ├── ExportController.js    # export:* events
│   └── SecurityController.js  # security:* events
├── services/
│   ├── JobService.js          # Business logic
│   ├── SettingsService.js
│   └── ExportService.js
└── repositories/
    └── JobRepository.js       # Persistence
```

## Related ADRs
- ADR-001: File Size Guardrail
- ADR-003: Dependency Injection over Global State

## References
- [Vertical Slice Architecture](https://jimmybogard.com/vertical-slice-architecture/)
- [Controller Pattern](https://martinfowler.com/eaaCatalog/pageController.html)
- Single Responsibility Principle (SOLID)
