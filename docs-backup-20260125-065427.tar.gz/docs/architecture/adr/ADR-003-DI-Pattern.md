# ADR-003: Dependency Injection over Global State

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** architecture, dependency-injection, testability

## Context

The current architecture uses **global state** and **implicit dependencies** to manage service relationships:

1. **Global State Pattern:**
   ```javascript
   // BackendAdapter.js
   global.backendAdapter = this;
   
   // JobRunner.js
   const adapter = global.backendAdapter;
   adapter.saveGeneratedImage(imageData);
   ```

2. **Process Module Exports:**
   ```javascript
   // BackendAdapter.js
   module.exports.backendAdapter = this;
   
   // JobRunner.js
   const { backendAdapter } = require('./backendAdapter');
   ```

3. **Circular Dependencies:**
   - `BackendAdapter` initializes and manages `JobRunner`
   - `JobRunner` depends on `BackendAdapter` for persistence
   - This creates a circular dependency resolved via fragile global state

**Problems:**
- **Untestable:** Cannot inject mocks for testing
- **Hidden Dependencies:** Dependencies are not explicit in function signatures
- **Tight Coupling:** Services are tightly coupled via global state
- **Fragile:** Global state can be undefined or overwritten
- **Hard to Reason About:** Dependencies are not visible in code structure

## Decision

We adopt **Dependency Injection (DI)** as the standard pattern for service dependencies:

1. **Constructor Injection:**
   - All services must accept their dependencies in the constructor
   - Dependencies are explicit and visible
   - **Bad Pattern:**
     ```javascript
     class JobRunner {
       saveImage(data) {
         global.backendAdapter.saveGeneratedImage(data);
       }
     }
     ```
   - **Good Pattern:**
     ```javascript
     class JobRunner {
       constructor(jobRepository) {
         this.jobRepository = jobRepository;
       }
       
       saveImage(data) {
         this.jobRepository.saveGeneratedImage(data);
       }
     }
     ```

2. **Service Container Pattern:**
   - A `ServiceContainer` or `AppFactory` (in `electron/main.js`) instantiates services in the correct order
   - Dependencies are resolved at application startup
   - Example:
     ```javascript
     // electron/main.js
     import { Database } from './src/infrastructure/Database';
     import { JobRepository } from './src/repositories/JobRepository';
     import { JobEngine } from './src/services/JobEngine';
     import { JobService } from './src/services/JobService';
     
     function createApp() {
       // Infrastructure layer
       const db = new Database();
       
       // Repository layer
       const jobRepository = new JobRepository(db);
       
       // Service layer
       const jobEngine = new JobEngine();
       const jobService = new JobService(jobRepository, jobEngine);
       
       return { jobService, jobRepository, /* ... */ };
     }
     ```

3. **Interface Segregation:**
   - Services depend on interfaces (repositories), not concrete implementations
   - `JobRunner` depends on `JobRepository` interface, not `BackendAdapter`
   - Enables swapping implementations (e.g., in-memory repository for testing)

4. **Elimination of Global State:**
   - Remove all `global.backendAdapter` references
   - Remove process module exports used for dependency resolution
   - All dependencies must be injected explicitly

5. **Event-Driven Decoupling (Optional):**
   - For cross-cutting concerns, consider event emitters
   - `JobEngine` emits events (`job-complete`, `image-generated`)
   - `JobService` listens and handles persistence
   - This further decouples orchestration from persistence

## Consequences

### Positive
- **Testability:** Services can be tested with mocked dependencies
- **Explicit Dependencies:** Dependencies are visible in constructor signatures
- **Loose Coupling:** Services depend on interfaces, not concrete classes
- **Better Composition:** Services can be composed in different ways
- **Easier Refactoring:** Changing one service doesn't break others

### Negative
- **Initial Refactoring:** Requires updating all service constructors
- **Service Container Complexity:** Need to manage dependency graph
- **More Boilerplate:** Constructor injection adds parameter lists

### Migration Path
1. **Phase 1:** Create `ServiceContainer` in `main.js`
2. **Phase 2:** Refactor `JobRunner` to accept `JobRepository` in constructor
3. **Phase 3:** Update `BackendAdapter` to use DI pattern
4. **Phase 4:** Remove all `global.backendAdapter` references
5. **Phase 5:** Add integration tests to verify DI wiring

## Example Refactoring

### Before (Global State):
```javascript
// BackendAdapter.js
class BackendAdapter {
  constructor() {
    this.jobRunner = new JobRunner();
    global.backendAdapter = this;
  }
}

// JobRunner.js
class JobRunner {
  saveImage(data) {
    global.backendAdapter.saveGeneratedImage(data);
  }
}
```

### After (Dependency Injection):
```javascript
// JobRepository.js
class JobRepository {
  constructor(db) {
    this.db = db;
  }
  
  saveGeneratedImage(data) {
    // Persistence logic
  }
}

// JobRunner.js
class JobRunner {
  constructor(jobRepository) {
    this.jobRepository = jobRepository;
  }
  
  saveImage(data) {
    this.jobRepository.saveGeneratedImage(data);
  }
}

// main.js
const db = new Database();
const jobRepository = new JobRepository(db);
const jobRunner = new JobRunner(jobRepository);
const backendAdapter = new BackendAdapter(jobRunner, jobRepository);
```

## Related ADRs
- ADR-001: File Size Guardrail
- ADR-002: Vertical Slice Architecture for IPC

## References
- [Dependency Injection](https://martinfowler.com/articles/injection.html)
- [Dependency Inversion Principle](https://en.wikipedia.org/wiki/Dependency_inversion_principle)
- [Service Locator vs Dependency Injection](https://martinfowler.com/articles/injection.html#ServiceLocatorVsDependencyInjection)
