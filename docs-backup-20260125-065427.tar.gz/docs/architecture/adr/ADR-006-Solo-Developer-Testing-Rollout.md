# ADR-006: Solo-Developer Testing & Rollout Strategy

**Status:** Accepted  
**Date:** 2025-01-27  
**Deciders:** Architecture Team  
**Tags:** testing, rollout, safety, brownfield-refactoring, feature-toggles

## Context

We are executing a brownfield refactoring of a production Electron/React application using the **Strangler Fig** pattern to replace monolithic files (3,400+ lines) without breaking production.

**Constraints:**
- **Solo Developer Workflow:** Pre-commit hooks → Push to `main` → CI → Release
- **No Feature Branches:** Direct commits to `main` branch
- **Production Safety:** Cannot break existing functionality during refactoring
- **Gradual Migration:** Must extract services incrementally while maintaining system stability
- **Zero Downtime:** Application must remain functional throughout the refactoring process

**Problem:**
- How do we safely ship new modular services while they're still being verified?
- How do we ensure legacy code paths remain functional during the transition?
- How do we test both new and old code paths without duplicating test suites?
- How do we rollback if a new service introduces regressions?

## Decision

We adopt a **Shadow Bridge Pattern with Feature Toggles** combined with a **mandatory testing stack** to ensure safe, incremental rollout of extracted services.

### 1. Feature Toggle System

**Rule:** Every new service extraction must be wrapped in a `process.env` feature flag.

**Naming Convention:**
- Format: `FEATURE_MODULAR_[SERVICE_NAME]`
- Examples:
  - `FEATURE_MODULAR_SECURITY` - SecurityService extraction
  - `FEATURE_MODULAR_JOB_REPOSITORY` - JobRepository extraction
  - `FEATURE_MODULAR_EXPORT` - ExportService extraction
  - `FEATURE_MODULAR_IPC_CONTROLLERS` - IPC Controller extraction

**Implementation Pattern:**
```javascript
// In BackendAdapter.js (Frozen Monolith)
async getApiKey(serviceName) {
  if (process.env.FEATURE_MODULAR_SECURITY === 'true') {
    return await this.securityService.getSecret(serviceName);
  } else {
    // Legacy implementation
    return await this._legacyGetApiKey(serviceName);
  }
}
```

**Default State:**
- All feature flags default to `false` (legacy code active)
- Flags are enabled via environment variables or configuration
- Production deployments use legacy code until explicitly enabled

### 2. Shadow Bridge Pattern

**The Bridge:** Frozen monolith files act as routers that delegate to new services when enabled.

**Zero-Deletion Policy:**
- **DO NOT** delete legacy code inside monoliths until new service is proven stable
- Legacy code remains as fallback during transition period
- Both code paths must pass tests during the transition

**Bridge Implementation:**
```javascript
// Example: BackendAdapter.js routing to SecurityService
class BackendAdapter {
  constructor() {
    // Initialize new service (always available)
    this.securityService = new SecurityService();
    
    // Legacy implementation remains intact
  }
  
  async getApiKey(serviceName) {
    // Bridge: Route to new service if enabled
    if (process.env.FEATURE_MODULAR_SECURITY === 'true') {
      try {
        return await this.securityService.getSecret(serviceName);
      } catch (error) {
        // Fallback to legacy if new service fails
        console.warn('New service failed, falling back to legacy:', error);
        return await this._legacyGetApiKey(serviceName);
      }
    }
    
    // Legacy path (default)
    return await this._legacyGetApiKey(serviceName);
  }
  
  // Legacy implementation (preserved until removal)
  async _legacyGetApiKey(serviceName) {
    // Original implementation
  }
}
```

### 3. Mandatory Testing Stack

**Three-Tier Testing Strategy:**

#### Tier 1: Unit & Integration Tests (Vitest)

**Purpose:** Verify new service logic in isolation with 100% coverage.

**Requirements:**
- Every new service must have a corresponding `.test.js` or `.test.ts` file
- Use **Vitest** for fast, isolated unit tests
- Mock all dependencies using Dependency Injection (ADR-003)
- Integration tests verify service interactions with real dependencies (database, file system)

**Coverage Target:**
- New services: **≥70% statement and branch coverage** (per ADR-001 testing standards)
- Bridge logic: **100% coverage** (both new and legacy paths)

**Example:**
```javascript
// src/services/SecurityService.test.js
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { SecurityService } from './SecurityService';

describe('SecurityService', () => {
  let securityService;
  let mockKeytar;
  
  beforeEach(() => {
    mockKeytar = {
      getPassword: vi.fn(),
      setPassword: vi.fn(),
    };
    securityService = new SecurityService(mockKeytar);
  });
  
  it('should get API key from keytar', async () => {
    mockKeytar.getPassword.mockResolvedValue('test-key');
    const result = await securityService.getSecret('openai');
    expect(result).toBe('test-key');
  });
});
```

#### Tier 2: Bridge Integration Tests (Vitest)

**Purpose:** Verify the bridge routing logic works correctly.

**Requirements:**
- Test both new service path (flag enabled) and legacy path (flag disabled)
- Verify fallback behavior when new service fails
- Test feature flag toggling behavior

**Example:**
```javascript
// tests/integration/backend/BackendAdapter.bridge.test.js
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { BackendAdapter } from '../../../src/adapter/backendAdapter';

describe('BackendAdapter Bridge Logic', () => {
  let adapter;
  
  beforeEach(() => {
    adapter = new BackendAdapter();
  });
  
  afterEach(() => {
    delete process.env.FEATURE_MODULAR_SECURITY;
  });
  
  it('should use new SecurityService when flag enabled', async () => {
    process.env.FEATURE_MODULAR_SECURITY = 'true';
    const result = await adapter.getApiKey('openai');
    // Verify new service was called
    expect(result).toBeDefined();
  });
  
  it('should use legacy implementation when flag disabled', async () => {
    process.env.FEATURE_MODULAR_SECURITY = 'false';
    const result = await adapter.getApiKey('openai');
    // Verify legacy path was used
    expect(result).toBeDefined();
  });
  
  it('should fallback to legacy if new service fails', async () => {
    process.env.FEATURE_MODULAR_SECURITY = 'true';
    // Mock new service to throw error
    adapter.securityService.getSecret = vi.fn().mockRejectedValue(new Error('Service failed'));
    
    const result = await adapter.getApiKey('openai');
    // Should fallback to legacy
    expect(result).toBeDefined();
  });
});
```

#### Tier 3: E2E & Regression Tests (Playwright)

**Purpose:** Full-flow verification and immutable safety net for legacy paths.

**Requirements:**
- Use **Playwright** for end-to-end testing
- Legacy 1,000-line integration test (`BackendAdapter.integration.test.ts`) remains as **Immutable Safety Net**
- E2E tests verify complete user workflows with both new and legacy code paths
- Tests must pass with feature flags both enabled and disabled

**Immutable Safety Net:**
- The existing `tests/integration/backend/BackendAdapter.integration.test.ts` (1,000 lines) is **frozen**
- This test suite ensures legacy code paths remain functional
- Must pass on every commit to `main`
- Cannot be modified during refactoring (only extended with new test cases)

**E2E Test Structure:**
```typescript
// tests/e2e/workflows/settings-security.e2e.test.ts
import { test, expect } from '@playwright/test';

test.describe('Settings Security Workflow', () => {
  test('should save API key with legacy implementation', async ({ page }) => {
    // Run with feature flag disabled
    process.env.FEATURE_MODULAR_SECURITY = 'false';
    
    await page.goto('file:///path/to/app');
    await page.fill('[data-testid="openai-api-key"]', 'test-key');
    await page.click('[data-testid="save-api-keys"]');
    
    await expect(page.locator('[data-testid="api-keys-saved"]')).toBeVisible();
  });
  
  test('should save API key with new SecurityService', async ({ page }) => {
    // Run with feature flag enabled
    process.env.FEATURE_MODULAR_SECURITY = 'true';
    
    await page.goto('file:///path/to/app');
    await page.fill('[data-testid="openai-api-key"]', 'test-key');
    await page.click('[data-testid="save-api-keys"]');
    
    await expect(page.locator('[data-testid="api-keys-saved"]')).toBeVisible();
  });
});
```

#### Tier 4: Frontend Component Tests (Vitest + React Testing Library)

**Purpose:** Test atomic components and custom hooks in isolation.

**Requirements:**
- Use **Vitest** with React Testing Library
- Test components as users interact with them
- Mock IPC calls and external dependencies
- Co-located tests in `__tests__/` directories (per testing strategy)

**Example:**
```typescript
// src/renderer/components/Settings/__tests__/ApiKeysSection.test.tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { ApiKeysSection } from '../ApiKeysSection';

describe('ApiKeysSection', () => {
  it('should save API key via IPC', async () => {
    const mockSetApiKey = vi.fn();
    global.window.api.setApiKey = mockSetApiKey;
    
    render(<ApiKeysSection />);
    
    const input = screen.getByLabelText('OpenAI API Key');
    fireEvent.change(input, { target: { value: 'test-key' } });
    
    const saveButton = screen.getByText('Save API Keys');
    fireEvent.click(saveButton);
    
    await waitFor(() => {
      expect(mockSetApiKey).toHaveBeenCalledWith('openai', 'test-key');
    });
  });
});
```

### 4. Rollout Workflow

**Five-Phase Process:**

#### Phase 1: Develop
1. Create new service (e.g., `SecurityService.js`)
2. Write comprehensive Vitest unit tests (≥70% coverage)
3. Write Vitest integration tests for service interactions
4. Ensure all tests pass locally

#### Phase 2: Bridge
1. Add feature flag to environment configuration
2. Implement bridge routing in frozen monolith
3. Write bridge integration tests (both paths)
4. Ensure legacy code path still works (run immutable safety net)

#### Phase 3: Ship
1. Commit to `main` branch (feature flag defaults to `false`)
2. CI runs full test suite:
   - Unit tests (Vitest)
   - Integration tests (Vitest)
   - Bridge tests (Vitest)
   - E2E tests (Playwright) - with flag disabled
   - Immutable safety net (Playwright)
3. Deploy to production (legacy code active)

#### Phase 4: Verify
1. Enable feature flag locally (`FEATURE_MODULAR_SECURITY=true`)
2. Run Playwright E2E suite with flag enabled
3. Verify all user workflows function correctly
4. Monitor for regressions or performance issues
5. If issues found, disable flag and investigate (legacy code remains active)

#### Phase 5: Finalize
1. Once stable in production for N releases (recommended: 2-3 releases)
2. Remove bridge logic and legacy implementation
3. Remove feature flag
4. Update tests to remove legacy path coverage
5. Mark service extraction as complete

### 5. Safety Mechanisms

**Pre-Commit Hooks:**
- Run critical test suite (`npm run test:critical`)
- ESLint validation
- Semgrep security scan
- All must pass before commit

**CI Pipeline:**
- Full test suite on every push to `main`
- Immutable safety net must pass (legacy paths)
- Bridge tests must pass (both paths)
- E2E tests run with flags disabled (default state)

**Rollback Strategy:**
- Feature flags default to `false` (legacy active)
- If new service fails, automatically fallback to legacy
- Can disable feature flag without code changes (environment variable)
- Legacy code remains intact until Phase 5

## Consequences

### Positive
- **Zero Downtime:** Legacy code remains active during transition
- **Safe Rollout:** Feature flags enable gradual, controlled migration
- **Easy Rollback:** Can disable new services without code changes
- **Comprehensive Testing:** Three-tier testing ensures quality
- **Immutable Safety Net:** Legacy test suite prevents regressions

### Negative
- **Code Duplication:** Both new and legacy code exist during transition
- **Increased Complexity:** Bridge logic adds routing overhead
- **Testing Overhead:** Must test both code paths
- **Technical Debt:** Legacy code remains until Phase 5

### Mitigation
- **Time-Bounded:** Feature flags are temporary (2-3 releases max)
- **Automated Testing:** CI ensures both paths work
- **Clear Process:** Phased rollout reduces risk
- **Documentation:** ADR provides clear guidelines

## Migration Example: SecurityService

### Phase 1: Develop
```javascript
// src/services/SecurityService.js (NEW)
class SecurityService {
  constructor(keytar) {
    this.keytar = keytar;
  }
  
  async getSecret(serviceName) {
    return await this.keytar.getPassword('gen-image-factory', serviceName);
  }
  
  async setSecret(serviceName, value) {
    await this.keytar.setPassword('gen-image-factory', serviceName, value);
  }
}
```

### Phase 2: Bridge
```javascript
// src/adapter/backendAdapter.js (FROZEN - Bridge Added)
class BackendAdapter {
  constructor() {
    this.securityService = new SecurityService(keytar);
  }
  
  async getApiKey(serviceName) {
    if (process.env.FEATURE_MODULAR_SECURITY === 'true') {
      return await this.securityService.getSecret(serviceName);
    }
    // Legacy implementation preserved
    return await this._legacyGetApiKey(serviceName);
  }
  
  async _legacyGetApiKey(serviceName) {
    // Original implementation (preserved)
  }
}
```

### Phase 3: Ship
- Commit to `main`
- CI runs all tests (flag disabled)
- Deploy to production (legacy active)

### Phase 4: Verify
- Enable flag locally
- Run E2E tests
- Verify functionality

### Phase 5: Finalize
```javascript
// src/adapter/backendAdapter.js (Legacy Removed)
class BackendAdapter {
  constructor() {
    this.securityService = new SecurityService(keytar);
  }
  
  async getApiKey(serviceName) {
    // Only new implementation remains
    return await this.securityService.getSecret(serviceName);
  }
}
```

## Related ADRs
- ADR-001: File Size Guardrail (frozen monoliths)
- ADR-002: Vertical Slice Architecture for IPC
- ADR-003: Dependency Injection over Global State
- ADR-007: CSS Standards - Tailwind-First Development

## References
- [Strangler Fig Pattern](https://martinfowler.com/bliki/StranglerFigApplication.html)
- [Feature Toggles](https://martinfowler.com/articles/feature-toggles.html)
- [Testing Strategy](../testing-strategy.md)
- [Vitest Documentation](https://vitest.dev/)
- [Playwright Documentation](https://playwright.dev/)
