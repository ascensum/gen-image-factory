# Data Models and Schema Changes

A new local SQLite database will be introduced with three core models.

* **`JobConfiguration`**: Saves a user's complete set of settings for a generation task, including:
  - **API Keys**: openai, piapi, removeBg (securely stored)
  - **File Paths**: outputDirectory, tempDirectory, systemPromptFile, keywordsFile, qualityCheckPromptFile, metadataPromptFile
  - **Parameters**: processMode, aspectRatios, mjVersion, openaiModel, pollingTimeout, keywordRandom, count
  - **Processing**: removeBg, imageConvert, imageEnhancement, sharpening, saturation, convertToJpg, trimTransparentBackground, jpgBackground, jpgQuality, pngQuality, removeBgSize
  - **AI**: runQualityCheck, runMetadataGen
  - **Advanced**: debugMode

* **`JobExecution`**: Stores the historical record of a specific run of a `JobConfiguration`.
  - Field added (migration 002): `label TEXT NULL` for human-friendly job names.

* **`GeneratedImage`**: Stores the results for each individual image, with the following key attributes:
    * `id`, `executionId`
    * `generationPrompt`: The final prompt sent to the image generation API.
    * `seed`: The seed number used for the generation.
    * `qcStatus`: ('Passed', 'Failed').
    * `qcReason`: The reason for failure.
    * `finalImagePath`: The path to the final image file.
    * `metadata`: A JSON object containing the AI-generated `title`, `description`, and `tags`.
    * `processingSettings`: JSON object containing the image processing settings applied:
      - `imageEnhancement`: boolean - Whether image enhancement was applied
      - `sharpening`: number - Sharpening intensity used (0-10)
      - `saturation`: number - Saturation level used (0-2)
      - `imageConvert`: boolean - Whether image conversion was applied
      - `convertToJpg`: boolean - Whether converted to JPG format
      - `jpgQuality`: number - JPG quality setting used (1-100)
      - `pngQuality`: number - PNG quality setting used (1-100)
      - `removeBg`: boolean - Whether background removal was applied
      - `removeBgSize`: string - Remove.bg size setting used
      - `trimTransparentBackground`: boolean - Whether transparent background trimming was applied
      - `jpgBackground`: string - JPG background color setting used

## Security Implementation (Story 1.13)

### API Key Storage Strategy
The application implements a three-tier security approach for API key storage:

#### **Tier 1: Native OS Keychain (Primary)**
- Uses `keytar` library for secure storage
- Stores API keys in native OS credential manager
- Maximum security for production environments
- Platform-specific: Keychain (macOS), Credential Manager (Windows), Secret Service (Linux)

#### **Tier 2: Encrypted Database (Fallback)**
- Encrypts API keys in SQLite database when keytar unavailable
- Uses Node.js `crypto` module for encryption
- Encryption key generated from system entropy
- Secure fallback for environments where keytar fails

#### **Tier 3: Plain Text Database (Development Only)**
- Current implementation for development/testing
- Will be replaced by encrypted database in Story 1.13
- Acceptable for development but not for production

### Security Schema Extensions
```sql
-- Security status tracking
security_storage_method VARCHAR(20) DEFAULT 'keytar',
security_encryption_status VARCHAR(20) DEFAULT 'available',
security_last_check TIMESTAMP DEFAULT CURRENT_TIMESTAMP

-- Encrypted API keys (Story 1.13)
encrypted_api_keys TEXT,  -- JSON object with encrypted API keys
encryption_key_hash VARCHAR(64),  -- Hash of encryption key for validation
```

### Memory Protection
- API keys cleared from memory on application exit
- Sensitive data masked in logs and error messages
- Secure string handling for API key operations
- Memory clearing for sensitive data in transit

## Repository Pattern Architecture (ADR-009)

### **CRITICAL: Database Model Decomposition (Epic 3 - Story 3.2)**

**Current State:** Database models violate SRP by combining schema definitions with business logic.

**Target Architecture:**

#### **Models (Schema Only) - Target: < 200 lines each**
- **Responsibility:** Only Sequelize/SQLite schema definitions
- **Contains:**
  - Table structure (columns, types, constraints)
  - Foreign key relationships
  - Index definitions
  - Basic validation rules (NOT NULL, UNIQUE, etc.)
- **NO Business Logic:** All query methods, transformations, and calculations extracted to repositories

#### **Repository Layer - New Services (< 400 lines each)**
- **Location:** `src/repositories/`
- **Structure:**
  - `JobRepository.js` - JobExecution CRUD and queries
  - `ImageRepository.js` - GeneratedImage CRUD and queries
  - `JobConfigurationRepository.js` - JobConfiguration CRUD and queries

#### **Extraction Boundaries:**

**1. JobRepository (from JobExecution.js - 1,100 lines)**
- **Extract Methods:**
  - `getJobHistory(limit)` - Complex JOIN query with aggregations
  - `getJobStatistics()` - Statistics calculations
  - `getJobExecution(id)` - Data transformation and parsing
  - `saveJobExecution(data)` - Business logic for saving
  - `updateJobExecution(id, data)` - Update logic with validation
  - `deleteJobExecution(id)` - Deletion with cascade handling
  - `getJobExecutions(filters)` - Filtered queries
- **Model Retains:** Schema definition + init() + close() methods only
- **Target:** Model ~150 lines (schema only)

**2. ImageRepository (from GeneratedImage.js - 1,000 lines)**
- **Extract Methods:**
  - `getImageMetadata(executionId)` - JOIN queries with parsing
  - `getImageStatistics()` - Aggregation queries
  - `updateMetadataById(id, metadata)` - JSON merge logic
  - `getImagesByQcStatus(status)` - Filtered queries
  - `bulkUpdateQcStatus(mapping)` - Batch operations
  - `deleteImagesByExecution(executionId)` - Cascade deletion
- **Model Retains:** Schema definition + init() + close() methods only
- **Target:** Model ~150 lines (schema only)

#### **Repository Interface Pattern:**
```javascript
class JobRepository {
  constructor(database) {
    this.db = database; // Injected database connection (ADR-003)
  }
  
  // CRUD Operations
  async create(data) { }
  async findById(id) { }
  async update(id, data) { }
  async delete(id) { }
  
  // Business Queries
  async getHistory(limit) { }
  async getStatistics() { }
  async findByFilters(filters) { }
}
```

#### **Dependency Injection (ADR-003):**
- Repositories accept database connection in constructor
- Models provide database connection via `init()` method
- Services depend on Repositories, not Models directly

#### **Testing Requirements:**
- **Repository Tests:** Unit tests with mocked database (≥70% coverage)
- **Integration Tests:** Use isolated test databases
- **Model Tests:** Schema verification only (no business logic tests)

#### **Feature Toggle (ADR-006):**
- **Flag:** `FEATURE_MODULAR_REPOSITORY`
- **Bridge Pattern:** Models delegate to repositories when flag enabled
- **Default State:** `false` (legacy code active)

#### **Migration Path (5 Phases):**
1. **Phase 1:** Create repository layer with comprehensive tests
2. **Phase 2:** Add bridge pattern with feature toggle
3. **Phase 3:** Update services to use repositories
4. **Phase 4:** Remove business logic from models
5. **Phase 5:** Remove feature flag after 2-3 stable releases

## New Image Enhancement Schema

### JobConfiguration Processing Fields
The `JobConfiguration` model now includes enhanced processing options with proper feature dependencies:

```sql
-- Processing section in JobConfiguration
processing_removeBg BOOLEAN DEFAULT FALSE,
processing_imageConvert BOOLEAN DEFAULT FALSE,
processing_imageEnhancement BOOLEAN DEFAULT FALSE,  -- NEW: Independent image enhancement toggle
processing_sharpening DECIMAL(3,1) DEFAULT 5.0,     -- NEW: Sharpening intensity (0-10)
processing_saturation DECIMAL(2,1) DEFAULT 1.4,     -- NEW: Saturation level (0-2)
processing_convertToJpg BOOLEAN DEFAULT FALSE,
processing_trimTransparentBackground BOOLEAN DEFAULT FALSE,
processing_jpgBackground VARCHAR(20) DEFAULT 'white',
processing_jpgQuality INTEGER DEFAULT 90,
processing_pngQuality INTEGER DEFAULT 90,
processing_removeBgSize VARCHAR(10) DEFAULT 'auto'
```

### Feature Dependency Logic
The database schema supports the following conditional logic:
- `trimTransparentBackground` requires `removeBg` to be true
- `jpgBackground` requires `removeBg` AND `imageConvert` AND `convertToJpg` to be true
- `imageEnhancement` is independent of `imageConvert` (can be enabled separately)
- Quality settings (`jpgQuality`, `pngQuality`) require `imageConvert` to be true 