# Code Standards

This document defines the coding standards and architectural principles for the Gen Image Factory codebase.

## Modularity and File Size Rules

### ADR Supremacy

**CRITICAL:** The following Architecture Decision Records (ADRs) **supersede any legacy patterns** found in the sharded architecture documents (`docs/architecture/*.md`). These ADRs establish new governance rules for the brownfield refactoring effort.

**Applicable ADRs:**
- **ADR-001:** File Size Guardrail (400-line limit)
- **ADR-002:** Vertical Slice Architecture for IPC
- **ADR-003:** Dependency Injection over Global State
- **ADR-006:** Solo-Developer Testing & Rollout Strategy (Feature toggles and safe rollout)
- **ADR-007:** CSS Standards - Tailwind-First Development
- **ADR-008:** Image Production Layer Extraction
- **ADR-009:** Persistence Repository Layer (Database model extraction)
- **ADR-010:** Frontend Decomposition Standard (React panel decomposition)
- **ADR-011:** Modular Testing Standard (Test file decomposition)
- **ADR-012:** Retry Executor Decomposition (Queue and processor separation)

### File Size Limit

**Rule:** All source files must be **< 400 lines**.

**Enforcement:**
- CI/Linting will warn on files > 400 lines
- Pre-commit hooks will flag violations
- Code review must reject PRs that introduce files > 400 lines

**Master Frozen List:**
The following files are **FROZEN** (no new logic may be added) and subject to the Strangler Fig pattern:

**Backend/Services:**
- `src/services/jobRunner.js` (3,381 lines) - *Extraction: ADR-002, ADR-003*
- `src/adapter/backendAdapter.js` (3,407 lines) - *Extraction: ADR-002, ADR-003*
- `src/producePictureModule.js` (799 lines) - *Extraction: ADR-008 (Image Production Layer)*
- `src/services/retryExecutor.js` (1,160 lines) - *Extraction: ADR-012 (Retry Executor Decomposition)*
- `src/database/models/JobExecution.js` (1,100 lines) - *Extraction: ADR-009 (Repository Layer)*
- `src/database/models/GeneratedImage.js` (1,000 lines) - *Extraction: ADR-009 (Repository Layer)*

**Frontend Components:**
- `src/renderer/components/Dashboard/DashboardPanel.tsx` (1,600 lines) - *Extraction: ADR-010 (Frontend Decomposition)*
- `src/renderer/components/Settings/SettingsPanel.tsx` (1,400 lines) - *Extraction: ADR-010 (Frontend Decomposition)*
- `src/renderer/components/Dashboard/FailedImagesReviewPanel.tsx` (1,200 lines) - *Extraction: ADR-010 (Frontend Decomposition)*
- `src/renderer/components/Jobs/JobManagementPanel.tsx` (1,100 lines) - *Extraction: ADR-010 (Frontend Decomposition)*

**Infrastructure/Tests:**
- `tests/integration/backend/BackendAdapter.integration.test.ts` (1,000 lines) - *Extraction: ADR-011 (Modular Testing)*

**Component Styling:**
- `src/renderer/components/Jobs/SingleJobView.css` (1,300 lines) - *Must refactor to Tailwind (see ADR-007)*

**Note:** Database models should be reduced to < 200 lines containing only schema definitions. All query logic must move to Repository Layer.

**Mitigation:**
- If a Service exceeds 400 lines, it **must** be split by feature/responsibility
- Split by domain boundaries, not arbitrary line counts
- Example: `JobRunner.js` → `JobInitializer.js`, `JobExecutor.js`, `JobFinalizer.js`

**Exemptions:**
- Generated code (migration files, auto-generated types)
- Test files (only if they cover a single, cohesive test suite)
- Configuration files (JSON, YAML)

### IPC Handler Architecture

**Rule:** IPC handlers must follow Vertical Slice Architecture (ADR-002).

**Structure:**
- IPC handlers are defined in dedicated Controller files per feature domain
- `src/controllers/JobController.js` handles `job:*` events
- `src/controllers/SettingsController.js` handles `settings:*` events
- `src/controllers/ExportController.js` handles `export:*` events
- `src/controllers/SecurityController.js` handles `security:*` events

**Handler Size Limit:**
- Each IPC handler must be **< 5 lines**
- Handlers are thin adapters that delegate to Services
- **Bad Pattern:**
  ```javascript
  ipc.handle('job:start', async (event, args) => {
    // 50 lines of validation
    // 30 lines of transformation
    // 20 lines of error handling
  })
  ```
- **Good Pattern:**
  ```javascript
  ipc.handle('job:start', (event, args) => 
    jobService.start(args)
  )
  ```

### Dependency Injection

**Rule:** All services must use Dependency Injection (ADR-003).

**Pattern:**
- All services must accept their dependencies in the constructor
- Dependencies are explicit and visible
- **Forbidden:** `global.backendAdapter`, process module exports for dependency resolution
- **Required:** Constructor injection with explicit dependencies

**Service Container:**
- A `ServiceContainer` or `AppFactory` (in `electron/main.js`) instantiates services in the correct order
- Dependencies are resolved at application startup

**Example:**
```javascript
// Bad: Global state
class JobRunner {
  saveImage(data) {
    global.backendAdapter.saveGeneratedImage(data);
  }
}

// Good: Dependency injection
class JobRunner {
  constructor(jobRepository) {
    this.jobRepository = jobRepository;
  }
  
  saveImage(data) {
    this.jobRepository.saveGeneratedImage(data);
  }
}
```

## Service Boundaries

### Service Extraction Strategy

When extracting services from monoliths, follow these boundaries:

1. **SecurityService (Infrastructure)**
   - Responsibility: API Key management, encryption/decryption, keytar interaction
   - Extracted from: BackendAdapter (lines ~50-150)
   - Interface: `getSecret(key)`, `setSecret(key, val)`, `getPublicSettings()`

2. **JobRepository (Persistence)**
   - Responsibility: CRUD operations for JobConfiguration, JobExecution, and GeneratedImage
   - Extracted from: BackendAdapter (lines ~1000-2000)
   - Goal: Isolate sequelize/sqlite logic. JobRunner should call `JobRepository.save(job)`, not build raw DB objects.

3. **ExportService (Feature)**
   - Responsibility: Generating Excel reports and ZIP archives
   - Extracted from: BackendAdapter (lines ~2200-2600)
   - Logic: Pure functional transformation of Data → File

4. **IPCController (Presentation)**
   - Responsibility: Mapping Electron IPC events to Service calls
   - Extracted from: BackendAdapter (lines ~300-900)
   - Rule: Handlers must be < 5 lines

5. **JobEngine (Core Domain)**
   - Responsibility: Pure orchestration of the generation pipeline (Init → ParamGen → ImageGen → QC → Metadata)
   - Refactoring: Strip out all direct DB calls. Return "Result Objects" that the JobService (orchestrator) persists via JobRepository.

## Legacy Code Treatment

### Strangler Fig Pattern

Legacy monolithic files (`jobRunner.js`, `backendAdapter.js`) are subject to the "Strangler Fig" pattern:

1. **Freeze:** No new logic may be added to these files
2. **Extract:** New features must extract to new Services/Repositories
3. **Gradual Migration:** Move logic from monoliths to new services incrementally
4. **Removal:** Once monoliths are thin facades, remove them entirely

### Migration Priority

1. **Phase 1 (Extraction):** Create `src/services/SecurityService.js` and move encryption logic there. Refactor BackendAdapter to use it.
2. **Phase 2 (Repo Pattern):** Create `src/repositories/JobRepository.js`. Move DB calls from BackendAdapter there.
3. **Phase 3 (Decouple):** Update JobRunner to emit events (`job-complete`, `image-generated`) instead of calling `backendAdapter.save()`. Let a new JobService listener handle the persistence.

## Testing Standards

### Testing & Rollout Strategy (ADR-006)

**Feature Toggle System:**
- Every new service extraction must be wrapped in a `process.env` feature flag
- Format: `FEATURE_MODULAR_[SERVICE_NAME]`
- Default state: `false` (legacy code active)
- Flags enable gradual, controlled migration

**Shadow Bridge Pattern:**
- Frozen monolith files act as routers that delegate to new services when enabled
- Zero-deletion policy: Legacy code remains until new service is proven stable
- Bridge logic must support fallback to legacy if new service fails

**Mandatory Testing Stack:**
- **Unit & Integration (Vitest):** ≥70% coverage for new services, 100% for bridge logic
- **Bridge Integration (Vitest):** Test both new and legacy code paths
- **E2E & Regression (Playwright):** Full-flow verification, immutable safety net
- **Frontend (Vitest + React Testing Library):** Atomic component testing

**Rollout Workflow:**
1. **Develop:** Create service + Vitest tests
2. **Bridge:** Wire into monolith behind feature flag
3. **Ship:** Push to `main` (legacy active)
4. **Verify:** Enable flag locally, run Playwright E2E
5. **Finalize:** Remove bridge and legacy code after 2-3 stable releases

### Unit Testing
- Services must be testable in isolation with mocked dependencies
- Use Dependency Injection to enable mocking
- Test files may exceed 400 lines only if they cover a single, cohesive test suite
- New services require ≥70% statement and branch coverage

### Integration Testing
- Test service interactions with real dependencies (database, file system)
- Use isolated test databases (see `testing-strategy.md`)
- Bridge integration tests must verify both new and legacy code paths

### E2E Testing
- Use Playwright for full-flow verification
- Legacy integration test (`BackendAdapter.integration.test.ts`) is immutable safety net
- Must pass with feature flags both enabled and disabled

## CSS Standards (ADR-007)

**Rule:** Tailwind-First development with CSS file size limits.

**Primary Approach:**
- All styling must use Tailwind utility classes as the primary method
- Inline Tailwind classes in `.tsx` files are preferred
- Custom CSS should be the exception, not the rule

**CSS File Size Limit:**
- Component CSS files must be **< 100 lines**
- Files exceeding 100 lines must be refactored to Tailwind or split into CSS Modules
- **Target:** Move 90% of styling to inline Tailwind classes

**CSS Modules (Exception Cases):**
- Use CSS Modules (`.module.css`) only for:
  - Complex animations that cannot be expressed in Tailwind
  - Pseudo-selectors with complex logic (`:hover`, `:focus`, `:before`, `:after`)
  - Third-party component overrides that require specificity
- CSS Modules must be co-located with their component
- CSS Modules must remain < 100 lines

**Frozen CSS Files:**
- `src/renderer/components/Jobs/SingleJobView.css` (1,300 lines) - **FROZEN**
- No new styles may be added to frozen CSS files
- Must refactor to Tailwind utilities or CSS Modules

## Code Review Checklist

When reviewing code, ensure:

- [ ] Files are < 400 lines (or exempted)
- [ ] No new logic added to any file on the Master Frozen List
- [ ] CSS files are < 100 lines (or exempted)
- [ ] Styling uses Tailwind utilities as primary method
- [ ] IPC handlers are < 5 lines and delegate to Services
- [ ] Services use Dependency Injection (no global state)
- [ ] Dependencies are explicit in constructor signatures
- [ ] Service boundaries follow the defined extraction strategy

## References

- [ADR-001: File Size Guardrail](../architecture/adr/ADR-001-File-Size-Guardrail.md)
- [ADR-002: Vertical Slice Architecture for IPC](../architecture/adr/ADR-002-Vertical-Slice-IPC.md)
- [ADR-003: Dependency Injection over Global State](../architecture/adr/ADR-003-DI-Pattern.md)
- [ADR-006: Solo-Developer Testing & Rollout Strategy](../architecture/adr/ADR-006-Solo-Developer-Testing-Rollout.md)
- [ADR-007: CSS Standards - Tailwind-First Development](../architecture/adr/ADR-007-CSS-Standards.md)
- [ADR-008: Image Production Layer Extraction](../architecture/adr/ADR-008-Image-Production-Layer-Extraction.md)
- [ADR-009: Persistence Repository Layer](../architecture/adr/ADR-009-Persistence-Repository-Layer.md)
- [ADR-010: Frontend Decomposition Standard](../architecture/adr/ADR-010-Frontend-Decomposition-Standard.md)
- [ADR-011: Modular Testing Standard](../architecture/adr/ADR-011-Modular-Testing-Standard.md)
- [ADR-012: Retry Executor Decomposition](../architecture/adr/ADR-012-Retry-Executor-Decomposition.md)
- [Testing Strategy](../architecture/testing-strategy.md)
